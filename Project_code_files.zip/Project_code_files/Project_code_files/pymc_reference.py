"""
pymc_reference.py
=================
Bayesian linear regression fitted with PyMC's NUTS sampler.

Purpose
-------
This model exists only to provide a REFERENCE calibration curve. It has
nothing to do with neural networks. Because the model is linear with just a
handful of parameters, NUTS samples its posterior essentially perfectly. If
our calibration code is correct, this model's calibration curve should lie on
or very close to the diagonal. It therefore acts as a sanity check: it shows
what good calibration looks like, against which the BNN and MC-Dropout curves
can be compared.

Model
-----
Predict the 1-step-ahead closing price from the 5 past closing prices:

    y = beta0 + beta1 x1 + ... + beta5 x5 + epsilon,  epsilon ~ N(0, sigma_i)

Priors:
    beta0 .. beta5 ~ Normal(0, 1)

Noise model (two variants):
    homoskedastic  : sigma ~ HalfNormal(1)  (single fixed noise scale)
    heteroskedastic: log sigma_i = log_s0 + gamma * vol_i        [DEFAULT]
        where vol_i is the standardised within-window volatility (the std of
        the 5 input prices of window i, standardised with TRAIN-set mean/sd).
        This lets the predictive noise widen when the local volatility rises,
        which fixes the under-coverage seen in crisis test windows: a single
        sigma fitted on calm training data is too narrow once test-period
        (crisis) volatility exceeds training-period volatility.

Sampling:
    NUTS (PyMC default), 2000 draws, 1000 tuning steps, 4 chains,
    target_accept = 0.9, with convergence checks ENABLED. Max R-hat and min
    bulk-ESS are printed and returned so sampling quality is verifiable.

Only step 1 (one day ahead) is modelled. Predictions and intervals are
returned for step 1 only.
"""

import numpy as np

try:
    import pymc as pm
    _HAS_PYMC = True
except Exception:  # pragma: no cover - allows the rest of the project to run
    _HAS_PYMC = False


def _mutable_data(name, value):
    """Create a mutable data container that works across PyMC versions.

    Newer PyMC (6.x) makes pm.Data immutable by default, so set_data() later
    fails. Older PyMC used pm.MutableData or pm.Data(..., mutable=True).
    This helper tries each form so the model works regardless of version.
    """
    # PyMC 5/6 with explicit mutable flag.
    try:
        return pm.Data(name, value, mutable=True)
    except TypeError:
        pass
    # Older PyMC exposed a dedicated MutableData.
    if hasattr(pm, "MutableData"):
        return pm.MutableData(name, value)
    # Last resort: plain Data (only works if this version is mutable by default).
    return pm.Data(name, value)


def _fit_bayes_lr_one_step(X_train, y_train, X_test, y_test, step,
                           draws=2000, tune=1000, chains=4,
                           seed=42, cores=4, heteroskedastic=True):
    """Fit Bayesian linear regression for ONE forecast horizon.

    `step` is a 0-based column index into y_train / y_test, so step=0 is the
    1-day-ahead target, step=4 is the 5-day-ahead target. Called once per
    horizon by fit_bayes_lr() below.

    Parameters
    ----------
    X_train, X_test : (n, 5) past closing prices.
    y_train, y_test : (n, 5) future closing prices; only column 0 (step 1)
                      is used by this model.
    cores : number of CPU cores for sampling.
    heteroskedastic : if True (default), the observation noise is modelled as
        log sigma_i = log_s0 + gamma * vol_i, where vol_i is the standardised
        within-window volatility (std of the 5 inputs of window i). The
        standardisation statistics are computed from the TRAINING windows
        only and re-applied to the test windows, so there is no test-set
        leakage; at test time sigma_i adapts through the covariate, which is
        observable from the inputs alone. If False, the original single
        HalfNormal(1) sigma is used (kept for before/after comparison).

    Sampler
    -------
    NUTS (PyMC's default for continuous models) with target_accept = 0.9 and
    compute_convergence_checks=True. NUTS is the standard, low-risk choice
    for a small continuous model like this; the earlier Metropolis shortcut
    (chosen for speed) ran with convergence checks disabled, so R-hat/ESS
    were never verified. Max R-hat and min bulk-ESS are printed and returned.

    Returns
    -------
    results dict with:
        name             : "Bayes-LR"
        pred             : (n_test, 1) posterior-mean step-1 prediction
        samples          : (n_draws, n_test, 1) posterior predictive draws
        fx_low_95        : (n_test, 1)
        fx_high_95       : (n_test, 1)
        rmse_per_step    : [float]  (single value, step 1)
        rmse_overall     : float    (same value)
        step1_only       : True
        heteroskedastic  : bool, which noise model was used
        max_rhat         : float, worst R-hat across parameters (NaN if
                           unavailable)
        min_ess          : float, smallest bulk-ESS across parameters (NaN
                           if unavailable)
    """
    if not _HAS_PYMC:
        raise ImportError(
            "PyMC is not installed. Install with: pip install pymc")

    # Target for this specific forecast horizon.
    y_train_1 = y_train[:, step]
    y_test_1 = y_test[:, step]
    n_features = X_train.shape[1]

    # Within-window volatility covariate: std of each window's 5 inputs.
    # Standardised with TRAIN statistics only (no test-set leakage); the same
    # transform is applied to the test windows.
    vol_train_raw = X_train.std(axis=1)
    vol_test_raw = X_test.std(axis=1)
    vol_mu = float(vol_train_raw.mean())
    vol_sd = float(vol_train_raw.std()) or 1.0
    vol_train = (vol_train_raw - vol_mu) / vol_sd
    vol_test = (vol_test_raw - vol_mu) / vol_sd

    with pm.Model() as model:
        # Mutable data so we can swap in the test set for prediction.
        # Both X and the observed y are given a shared first dimension so the
        # test set (a different number of rows) can be substituted cleanly.
        X_data = _mutable_data("X_data", X_train)
        y_data = _mutable_data("y_data", y_train_1)
        vol_data = _mutable_data("vol_data", vol_train)

        beta0 = pm.Normal("beta0", mu=0.0, sigma=1.0)
        betas = pm.Normal("betas", mu=0.0, sigma=1.0, shape=n_features)

        if heteroskedastic:
            # log sigma_i = log_s0 + gamma * vol_i. When gamma = 0 this
            # collapses to a single fixed noise scale, so the homoskedastic
            # model is nested inside this one.
            log_s0 = pm.Normal("log_s0", mu=-2.0, sigma=1.5)
            gamma = pm.Normal("gamma", mu=0.0, sigma=1.0)
            sigma = pm.Deterministic(
                "sigma", pm.math.exp(log_s0 + gamma * vol_data))
        else:
            sigma = pm.HalfNormal("sigma", sigma=1.0)

        mu = beta0 + pm.math.dot(X_data, betas)
        pm.Normal("y_obs", mu=mu, sigma=sigma, observed=y_data,
                  shape=mu.shape)

        idata = pm.sample(
            draws=draws, tune=tune, chains=chains, cores=cores,
            target_accept=0.9,          # NUTS (PyMC default step method)
            random_seed=seed,
            progressbar=True, compute_convergence_checks=True,
        )

        # Report convergence diagnostics (R-hat / bulk-ESS) explicitly, so
        # sampling quality is verifiable rather than assumed.
        max_rhat = float("nan")
        min_ess = float("nan")
        try:
            import arviz as az
            free_vars = [v.name for v in model.free_RVs]
            rhat = az.rhat(idata, var_names=free_vars)
            ess = az.ess(idata, var_names=free_vars)
            max_rhat = float(max(rhat[v].values.max() for v in rhat.data_vars))
            min_ess = float(min(ess[v].values.min() for v in ess.data_vars))
            print(f"    Bayes-LR step-{step + 1} convergence: "
                  f"max R-hat = {max_rhat:.4f}, min bulk-ESS = {min_ess:.0f}")
            if max_rhat > 1.01:
                print("    WARNING: R-hat > 1.01 - chains may not have "
                      "converged.")
        except Exception as e:  # pragma: no cover - diagnostics only
            print(f"    (convergence diagnostics unavailable: {e})")

        # Posterior predictive on the test set. Substitute X, the volatility
        # covariate and a dummy y of the correct test length so shapes stay
        # consistent.
        pm.set_data({"X_data": X_test, "y_data": y_test_1,
                     "vol_data": vol_test})
        ppc = pm.sample_posterior_predictive(
            idata, var_names=["y_obs"], progressbar=False,
            random_seed=seed,
        )

    # ppc.posterior_predictive["y_obs"] has shape (chains, draws, n_test).
    pp = ppc.posterior_predictive["y_obs"].values
    n_chains, n_draws, n_test = pp.shape
    samples_flat = pp.reshape(n_chains * n_draws, n_test)   # (S, n_test)

    # Reshape to (S, n_test, 1) for uniform interface.
    samples = samples_flat[:, :, None]

    pred_mean = samples.mean(axis=0)                  # (n_test, 1)
    fx_low_95 = np.percentile(samples, 2.5, axis=0)   # (n_test, 1)
    fx_high_95 = np.percentile(samples, 97.5, axis=0)

    rmse = float(np.sqrt(np.mean((y_test_1 - pred_mean[:, 0]) ** 2)))

    return {
        "pred": pred_mean,          # (n_test, 1)
        "samples": samples,         # (S, n_test, 1)
        "fx_low_95": fx_low_95,
        "fx_high_95": fx_high_95,
        "rmse": rmse,
        "max_rhat": max_rhat,
        "min_ess": min_ess,
    }


def fit_bayes_lr(X_train, y_train, X_test, y_test,
                 draws=2000, tune=1000, chains=4,
                 seed=42, cores=4, heteroskedastic=True, n_steps=None):
    """Fit Bayesian linear regression across ALL forecast horizons.

    Previously this model was fitted on the step-1 target only, while the BNN
    and the deterministic baselines predicted all 5 horizons. That made the
    headline RMSE comparison an unequal one: Bayes-LR was being scored purely
    on the easiest horizon (1 day ahead) while the other models were scored on
    the average across horizons 1-5, which necessarily includes the harder,
    further-out predictions. This function now fits one independent regression
    per horizon, so every model is evaluated on exactly the same task.

    Parameters
    ----------
    X_train, X_test : (n, 5) past closing prices.
    y_train, y_test : (n, H) future closing prices; all H columns are used.
    n_steps : number of horizons to fit. Defaults to y_train.shape[1].
    heteroskedastic : see _fit_bayes_lr_one_step.

    Returns
    -------
    results dict with:
        name             : "Bayes-LR"
        pred             : (n_test, H) posterior-mean predictions
        samples          : (n_draws, n_test, H) posterior predictive draws
        fx_low_95        : (n_test, H)
        fx_high_95       : (n_test, H)
        rmse_per_step    : [float] * H
        rmse_overall     : float, RMSE pooled across all horizons
        step1_only       : False
        heteroskedastic  : bool
        max_rhat         : worst R-hat across all horizons
        min_ess          : smallest bulk-ESS across all horizons
    """
    if not _HAS_PYMC:
        raise ImportError(
            "PyMC is not installed. Install with: pip install pymc")

    H = int(n_steps) if n_steps is not None else int(y_train.shape[1])

    preds, sample_list, los, his, rmses = [], [], [], [], []
    rhats, esss = [], []

    for step in range(H):
        r = _fit_bayes_lr_one_step(
            X_train, y_train, X_test, y_test, step,
            draws=draws, tune=tune, chains=chains,
            # Vary the seed per horizon so the horizons are not identical
            # draws of the same random stream.
            seed=seed + step, cores=cores, heteroskedastic=heteroskedastic)
        preds.append(r["pred"][:, 0])
        sample_list.append(r["samples"][:, :, 0])
        los.append(r["fx_low_95"][:, 0])
        his.append(r["fx_high_95"][:, 0])
        rmses.append(r["rmse"])
        rhats.append(r["max_rhat"])
        esss.append(r["min_ess"])

    pred_mean = np.stack(preds, axis=1)                 # (n_test, H)
    samples = np.stack(sample_list, axis=2)             # (S, n_test, H)
    fx_low_95 = np.stack(los, axis=1)                   # (n_test, H)
    fx_high_95 = np.stack(his, axis=1)

    # Pooled across all horizons, matching how the BNN's rmse_overall is
    # computed, so the two are directly comparable.
    rmse_overall = float(np.sqrt(np.mean(
        (y_test[:, :H] - pred_mean) ** 2)))

    finite_rhats = [v for v in rhats if np.isfinite(v)]
    finite_esss = [v for v in esss if np.isfinite(v)]

    return {
        "name": "Bayes-LR",
        "pred": pred_mean,
        "samples": samples,
        "fx_low_95": fx_low_95,
        "fx_high_95": fx_high_95,
        "rmse_per_step": [float(v) for v in rmses],
        "rmse_overall": rmse_overall,
        "step1_only": False,
        "n_steps": H,
        "heteroskedastic": bool(heteroskedastic),
        "max_rhat": float(max(finite_rhats)) if finite_rhats else float("nan"),
        "min_ess": float(min(finite_esss)) if finite_esss else float("nan"),
    }


if __name__ == "__main__":
    import data

    df = data.load_all_stocks(".")["MMM"]
    cfg = data.get_experiment_splits()["R1"]   # R1 = worst under-coverage
    Xtr, ytr, Xte, yte, td, sc = data.normalise_and_split(
        df, cfg["train_end"], cfg["test_start"], cfg["test_end"])

    for hetero in (False, True):
        label = "heteroskedastic" if hetero else "homoskedastic"
        res = fit_bayes_lr(Xtr, ytr, Xte, yte, draws=500, tune=500, chains=2,
                           heteroskedastic=hetero)
        inside = ((yte[:, 0] >= res["fx_low_95"][:, 0])
                  & (yte[:, 0] <= res["fx_high_95"][:, 0]))
        width = float(np.mean(res["fx_high_95"] - res["fx_low_95"]))
        print(f"[{label}] step-1 RMSE = {res['rmse_overall']:.4f}  "
              f"coverage@95 = {inside.mean():.3f}  "
              f"mean 95% width = {width:.4f}")
