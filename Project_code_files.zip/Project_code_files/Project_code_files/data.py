"""
data.py
=======
Data loading and preprocessing for the BNN stock forecasting project.

Responsibilities
----------------
- Load the four stock CSV files (Date, Open, High, Low, Close, Volume).
- Parse dates with dayfirst=True, sort chronologically.
- Min-max normalise the Close price using the TRAINING window only
  (no test-set leakage).
- Build sliding-window (X, y) pairs using Takens embedding with
  dimension D = 5 and time-lag T = 2.
- Define the six experimental setups (R1, R2, W1, W2, M1, M2).
- Provide helper functions for the additional OHLCV analyses
  (intraday range, volume ratio, volatility split, volume spikes).

Only the Close column is used for the model. Open/High/Low/Volume are
used purely for post-hoc analysis, never as model inputs.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


# ----------------------------------------------------------------------------
# Constants describing the embedding (Takens reconstruction)
# ----------------------------------------------------------------------------
EMBED_DIM = 5      # D : number of past values used as input
TIME_LAG = 2       # T : spacing between the past values
STEPS_AHEAD = 5    # number of future values predicted

# With D = 5 and T = 2 the input indices, relative to time t, are:
#   [t - 8, t - 6, t - 4, t - 2, t]
# and the output indices are:
#   [t + 1, t + 2, t + 3, t + 4, t + 5]
# So the earliest usable t must satisfy t - (D-1)*T >= 0, i.e. t >= 8.

# Map short stock keys to CSV file names.
STOCK_FILES = {
    "MMM": "MMM_clean.csv",
    "CBA_AX": "CBA_AX_clean.csv",
    "DAI_DE": "DAI_DE_clean.csv",
    "SS_600118": "600118_SS_clean.csv",
}


# ----------------------------------------------------------------------------
# Experimental setups
# ----------------------------------------------------------------------------
def get_experiment_splits():
    """Return the dictionary of all six experimental setup configurations.

    Each value contains train_end, test_start and test_end as strings in
    YYYY-MM-DD format. The same boundaries apply to all four stocks.
    """
    return {
        # COVID replication of the original paper
        "R1": {
            "train_end": "2020-01-31",
            "test_start": "2020-02-01",
            "test_end": "2020-06-30",
            "label": "COVID pre-shock training",
        },
        "R2": {
            "train_end": "2020-04-30",
            "test_start": "2020-05-01",
            "test_end": "2020-06-30",
            "label": "COVID includes early shock",
        },
        # Russia-Ukraine war
        "W1": {
            "train_end": "2022-02-23",
            "test_start": "2022-02-24",
            "test_end": "2022-12-31",
            "label": "Russia-Ukraine pre-war training",
        },
        "W2": {
            "train_end": "2022-04-30",
            "test_start": "2022-05-01",
            "test_end": "2022-12-31",
            "label": "Russia-Ukraine includes early war",
        },
        # Middle East conflict -- anchored on the 2025-26 escalation phase.
        #
        # Two constraints had to be satisfied at once:
        #   (a) the test window must be comparable in LENGTH to W1/W2, so that
        #       differences in coverage/RMSE reflect the crisis and not simply
        #       a longer window mixing crisis days with calm ones; and
        #   (b) the window must actually contain elevated volatility, or it is
        #       not testing crisis behaviour at all.
        #
        # The earlier 2023-10-07 -> 2026-06-01 window satisfied (b) but badly
        # violated (a): 968 days versus 310 for W1. Truncating it to
        # 2024-08-31 fixed the length but broke (b) -- measured against a
        # 2018-19 calm baseline, that onset window has a cross-stock mean
        # volatility ratio of only 1.05, i.e. essentially no elevation at all.
        #
        # Re-anchoring on the 2025 escalation satisfies both: the windows are
        # 364 / 272 days (vs 310 / 244 for W1 / W2) and carry cross-stock mean
        # volatility ratios of 1.35 / 1.42 -- higher than W1's own 1.25.
        # The 2025-06-01 anchor follows this study's convention of splitting on
        # the geopolitical event date rather than on a volatility trigger,
        # matching 2020-02-01, 2022-02-24 and 2023-10-07.
        "M1": {
            "train_end": "2025-05-31",
            "test_start": "2025-06-01",
            "test_end": "2026-05-31",
            "label": "Middle East 2025-26 escalation, pre-escalation training",
        },
        "M2": {
            "train_end": "2025-08-31",
            "test_start": "2025-09-01",
            "test_end": "2026-05-31",
            "label": "Middle East 2025-26 escalation, early escalation in training",
        },
    }


# ----------------------------------------------------------------------------
# CSV loading
# ----------------------------------------------------------------------------
def load_csv(filepath):
    """Load one CSV file.

    Returns a DataFrame sorted by Date with all OHLCV columns retained.
    The Date column is parsed with dayfirst=True (format DD-MM-YYYY).
    """
    df = pd.read_csv(filepath)
    df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)
    df = df.sort_values("Date").reset_index(drop=True)
    # Keep all columns; only Close is used by the model, the rest are for
    # post-hoc analysis.
    return df


def load_all_stocks(data_dir="."):
    """Load all four stocks.

    Returns a dict with keys MMM, CBA_AX, DAI_DE, SS_600118, each
    containing the full DataFrame with all OHLCV columns.
    """
    import os

    stocks = {}
    for key, fname in STOCK_FILES.items():
        path = os.path.join(data_dir, fname)
        stocks[key] = load_csv(path)
    return stocks


# ----------------------------------------------------------------------------
# Sliding window construction (Takens embedding, D = 5, T = 2)
# ----------------------------------------------------------------------------
def _make_windows(series):
    """Build (X, y) pairs and the aligned target dates from a 1-D array.

    series : 1-D numpy array of normalised closing prices.

    Returns
    -------
    X : (n_windows, EMBED_DIM)
    y : (n_windows, STEPS_AHEAD)
    end_idx : list of integer indices t used to build each window, so the
              caller can map each window back to the date of x(t).
    """
    n = len(series)
    span_back = (EMBED_DIM - 1) * TIME_LAG  # = 8 for D=5, T=2
    X_list, y_list, idx_list = [], [], []

    # t is the index of the most recent input value x(t).
    # Need t - span_back >= 0 and t + STEPS_AHEAD <= n - 1.
    for t in range(span_back, n - STEPS_AHEAD):
        input_idx = [t - (EMBED_DIM - 1 - k) * TIME_LAG for k in range(EMBED_DIM)]
        # input_idx = [t-8, t-6, t-4, t-2, t]
        output_idx = [t + 1 + h for h in range(STEPS_AHEAD)]
        X_list.append(series[input_idx])
        y_list.append(series[output_idx])
        idx_list.append(t)

    X = np.array(X_list, dtype=np.float64)
    y = np.array(y_list, dtype=np.float64)
    return X, y, idx_list


def normalise_and_split(df, train_end, test_start, test_end):
    """Normalise the Close price and build train/test windows.

    The MinMaxScaler is fitted ONLY on rows up to train_end, preventing
    leakage. The same scaler is then applied to the whole series, so test
    values may legitimately fall outside [0, 1] during crises.

    Parameters
    ----------
    df : DataFrame with Date and Close columns.
    train_end, test_start, test_end : date strings YYYY-MM-DD.

    Returns
    -------
    X_train, y_train : training windows
    X_test, y_test   : test windows
    test_dates       : list of pandas Timestamps, the date of x(t) for each
                       test window (the last input day of that window)
    scaler           : the fitted MinMaxScaler
    """
    train_end = pd.Timestamp(train_end)
    test_start = pd.Timestamp(test_start)
    test_end = pd.Timestamp(test_end)

    dates = df["Date"].values
    close = df["Close"].values.astype(np.float64).reshape(-1, 1)

    # Fit scaler on training rows only.
    train_mask = df["Date"] <= train_end
    scaler = MinMaxScaler()
    scaler.fit(close[train_mask.values])

    close_norm = scaler.transform(close).flatten()

    # Build all windows over the entire normalised series.
    X_all, y_all, idx_all = _make_windows(close_norm)

    # Map each window to the date of its last input value x(t).
    window_dates = pd.to_datetime([dates[t] for t in idx_all])

    # A window belongs to TRAIN if x(t) is on or before train_end.
    # A window belongs to TEST if x(t) is within [test_start, test_end].
    # Using x(t) as the anchor guarantees that all five outputs are strictly
    # in the future relative to the input, and that no training window peeks
    # into the test period.
    train_sel = window_dates <= train_end
    test_sel = (window_dates >= test_start) & (window_dates <= test_end)

    X_train = X_all[train_sel]
    y_train = y_all[train_sel]
    X_test = X_all[test_sel]
    y_test = y_all[test_sel]
    test_dates = list(window_dates[test_sel])

    return X_train, y_train, X_test, y_test, test_dates, scaler


# ----------------------------------------------------------------------------
# Additional analyses (Open/High/Low/Volume) -- never used as model inputs
# ----------------------------------------------------------------------------
def compute_intraday_range(df):
    """Daily intraday range as a fraction of the closing price.

    intraday_range = (High - Low) / Close

    Returns a pandas Series indexed like df.
    """
    return (df["High"] - df["Low"]) / df["Close"]


def compute_volume_ratio(df):
    """Volume relative to its 20-day rolling mean.

    vol_ratio = Volume / Volume.rolling(20).mean()

    The leading NaN values (first 19 rows) are back-filled so the series is
    complete. Returns a pandas Series indexed like df.
    """
    vol_ma20 = df["Volume"].rolling(20).mean()
    vol_ratio = df["Volume"] / vol_ma20
    vol_ratio = vol_ratio.bfill()
    return vol_ratio


def get_volatility_split(test_dates, high_series, low_series, close_series):
    """Split the test set into low- and high-volatility days.

    Volatility is measured by the intraday range (High - Low) / Close on
    each test day. The split point is the median intraday range across the
    test days. Days at or below the median go to the low-volatility group,
    days strictly above go to the high-volatility group.

    Parameters
    ----------
    test_dates : list of Timestamps, one per test window (date of x(t)).
    high_series, low_series, close_series : pandas Series indexed by Date
        (or by integer with a parallel Date column). They must be indexed so
        that .loc[date] returns the value for that date. The simplest way to
        guarantee this is to pass Series indexed by the DataFrame's Date.

    Returns
    -------
    low_vol_mask, high_vol_mask : boolean numpy arrays of length len(test_dates)
    range_median : float, the threshold used
    """
    test_dates = pd.to_datetime(list(test_dates))

    # high_series etc. are expected to be indexed by Date.
    highs = high_series.reindex(test_dates).values
    lows = low_series.reindex(test_dates).values
    closes = close_series.reindex(test_dates).values

    intraday = (highs - lows) / closes
    range_median = float(np.nanmedian(intraday))

    low_vol_mask = intraday <= range_median
    high_vol_mask = intraday > range_median

    # Guard against NaN (should not happen with clean data): treat NaN as low.
    nan_mask = np.isnan(intraday)
    low_vol_mask = low_vol_mask & (~nan_mask)
    high_vol_mask = high_vol_mask & (~nan_mask)

    return low_vol_mask, high_vol_mask, range_median


def compute_volume_spikes(vol_ratio_series, test_dates, top_n=10):
    """Identify the top-n highest volume-ratio days within the test window.

    Parameters
    ----------
    vol_ratio_series : pandas Series of volume ratios indexed by Date
        (covering the full history, since the rolling mean needs prior days).
    test_dates : list of Timestamps for the test windows.
    top_n : how many spike days to return.

    Returns
    -------
    DataFrame with columns [date, vol_ratio] for the top-n test days,
    sorted by vol_ratio descending. The caller adds prediction-error columns.
    """
    test_dates = pd.to_datetime(list(test_dates))
    sub = vol_ratio_series.reindex(test_dates)
    sub = sub.dropna()
    top = sub.sort_values(ascending=False).head(top_n)
    out = pd.DataFrame({"date": top.index, "vol_ratio": top.values})
    return out.reset_index(drop=True)


def monthly_intraday_summary(df, stock_name):
    """Monthly mean intraday range for the volatility chart and summary CSV.

    Returns a DataFrame with columns stock, year, month, mean_intraday_range.
    """
    tmp = df.copy()
    tmp["intraday_range"] = compute_intraday_range(tmp)
    tmp["year"] = tmp["Date"].dt.year
    tmp["month"] = tmp["Date"].dt.month
    grp = (
        tmp.groupby(["year", "month"])["intraday_range"]
        .mean()
        .reset_index()
        .rename(columns={"intraday_range": "mean_intraday_range"})
    )
    grp.insert(0, "stock", stock_name)
    return grp


if __name__ == "__main__":
    # Quick self-test when run directly.
    stocks = load_all_stocks(".")
    splits = get_experiment_splits()
    for name, df in stocks.items():
        print(f"{name}: {len(df)} rows, "
              f"{df['Date'].min().date()} to {df['Date'].max().date()}")
    print()
    for setup, cfg in splits.items():
        df = stocks["MMM"]
        Xtr, ytr, Xte, yte, td, sc = normalise_and_split(
            df, cfg["train_end"], cfg["test_start"], cfg["test_end"])
        print(f"{setup}: train {Xtr.shape}, test {Xte.shape}, "
              f"test dates {td[0].date() if td else 'NONE'} "
              f"to {td[-1].date() if td else 'NONE'}")
