# BNN improvements (Task 4 of the handoff) — what changed and what we measured

## Changes implemented

**1. Heteroskedastic noise model (root-cause fix, item 1).**
`bnn.py` now supports per-window noise variance:

    tau_i^2 = exp(log_tau_sq + gamma_v * vol_i)

where `vol_i` is the standardised std of window i's five inputs (standardised
with TRAIN statistics only — no test-set leakage; the covariate is observable
from the inputs alone, so it is available at test time). `gamma_v` is sampled
in its own Metropolis block (BLOCK 3) with a N(0,1) prior and Robbins-Monro
step adaptation (target 0.44). `gamma_v = 0` recovers the original
homoskedastic model exactly, so the old model is nested inside the new one.
The parallel-tempering swap protocol now swaps the full (w, tau, gamma_v)
state, and the posterior predictive applies the per-test-row noise scale.
This is the same covariate and mechanism used to fix the Bayes-LR
under-coverage, so the story is consistent across models. Toggle off with
`--bnn-homoskedastic` for before/after comparisons.

**2. Loosened tau prior (item 2).** `gamma_a` 2.0 → 1.1 in `BNN_CONFIG`
(prior mean of tau^2 goes 0.05 → 0.5, i.e. a much heavier right tail, while
the mode region stays similar). The prior is deliberately NOT set from
test-period variance — that would leak crisis information.

**3. ESS diagnostic (item 3).** `run_bnn` now computes and prints the
effective sample size of the cold-chain posterior (predicted value at the
first test point, and tau), via a pure-numpy Geyer-style estimator, and
saves both into the per-run results JSON. A warning is printed when
ESS < 2% of the post-burn-in sample count.

**Bonus bug fix.** After a parallel-tempering swap, `chain_worker` previously
updated only the combined `cur_lp` but left the per-block `cur_lp_w` /
`cur_lp_tau` stale, so the first accept/reject after every swap used
pre-swap prior values. All per-block priors are now recomputed after a swap.

Items 4 (larger topology) and 5 (multi-run ensemble) from the handoff were
NOT implemented — both multiply compute cost and item 4 adds tuning burden;
revisit only if the coverage gap remains after the heteroskedastic fix.

## Validation (MMM / R1, reduced budget: 4 chains x 4000 samples)

| Variant                         | RMSE   | coverage@95 | gamma_v | ESS(pred) |
|---------------------------------|--------|-------------|---------|-----------|
| OLD (homoskedastic, a=2.0)      | 0.0466 | 0.735       | —       | 4 / 2000  |
| Loose prior only (homo, a=1.1)  | 0.0466 | 0.735       | —       | 4 / 2000  |
| NEW (heteroskedastic + a=1.1)   | 0.0468 | 0.894       | +0.795  | 5 / 2000  |

Honest readings:

- The OLD number (0.735) reproduces the R1 average from the saved full-run
  results (0.737), so the test setup is representative.
- **The loose prior alone changed nothing at this budget** — the handoff
  suggested trying it first as a cheap win, but empirically the likelihood
  dominates the prior here. Keep the loosened prior (it is more defensible),
  but the coverage gain comes from the heteroskedastic model.
- **The heteroskedastic model moves coverage 0.735 → 0.894** with essentially
  unchanged RMSE — intervals widen where volatility is high, point accuracy
  is untouched. The posterior mean of gamma_v (~+0.8) is strongly positive:
  the data themselves confirm volatility-dependent noise.
- **The ESS warning fired: ~4 effective samples out of 2000** at this reduced
  budget. This confirms the handoff's item-3 hypothesis of a second,
  independent under-coverage source (high autocorrelation artificially
  narrows the posterior). Expect better ESS at the full 100k budget, but
  check the printed ESS in the full run — if it is still very low, that is
  the next thing to fix (e.g. longer runs, more thinning-aware reporting, or
  the item-5 ensemble).
- Coverage at 0.894 is still short of 0.95 — do not oversell the fix. The
  within-window volatility covariate reacts to crises with a small lag, and
  the low ESS is still in play. The correct framing for the report: the
  heteroskedastic model removes most of the regime-dependent miscalibration
  that temperature scaling was patching post-hoc, and the remaining gap is
  attributable to sampling efficiency and covariate lag.

---

# Task 6 — Adaptive parallel-tempering ladder (swap acceptance fix)

## Change

The fixed geometric ladder (`np.geomspace(1.0, max_temp, n_chains)`) is
replaced by an adaptive ladder (Vousden, Farr & Mandel 2016 style; same idea
as emcee's PTSampler). During burn-in, the log of each neighbour gap gets a
decaying-gain Robbins-Monro update toward a per-pair swap acceptance of
0.234:

    S_k += kappa(t) * (accepted - target),  kappa(t) = kappa0 * t0 / (t + t0)

Details that matter:
- The cold chain stays fixed at T = 1.0 (its samples are the posterior).
- Adaptation starts only after `ladder_adapt_delay` (25) swap rounds:
  right after warm-up all chains sit near the same state, so nearly every
  swap is accepted regardless of gap size; adapting on those spurious
  accepts inflates the gaps. (Observed empirically: without the delay the
  hot-end gap grew instead of shrinking.)
- The ladder FREEZES at the end of burn-in, so all post-burn-in samples come
  from a fixed, detailed-balance-respecting scheme.
- Workers receive their (possibly retuned) temperature together with the
  swapped state each round.
- New health metric `swap_rate_post_burnin` (plus per-pair rates and the
  final ladder) is printed and saved to the results JSON - this measures the
  frozen ladder, which is what the posterior actually experienced. The old
  whole-run `swap_rate` mixes adaptation-phase noise in and understates
  post-freeze health.
- `max_temp` default 2.0 -> 1.5 (now only the ladder's starting point).
- Revert with `--fixed-ladder`.

## Why the old ladder failed (root cause, confirmed)

Swap acceptance depends on (1/Ta - 1/Tb) * (llb - lla). The log-likelihood
is a sum over N training points, so its chain-to-chain fluctuation grows
with N (~2000-3700 rows x 5 outputs here). The fixed geometric gaps were far
too wide for this N, so almost every swap was rejected and the cold chain
behaved like a single plain MCMC chain despite the tempering machinery -
consistent with the observed low tau ESS.

## Validation (MMM / R1, N_train = 2025, 6 chains x 3000 samples)

| Ladder                    | swap post-burn-in | per-pair rates            | final T_max | ESS(pred) |
|---------------------------|-------------------|---------------------------|-------------|-----------|
| Fixed (max_temp=2.0)      | 0.005             | 0.00/0.00/0.00/0.00/0.03  | 2.000       | 9         |
| Adaptive (init 1.5)       | 0.205             | 0.08/0.29/0.38/0.23/0.04  | 1.320       | 70        |

Honest readings:
- 0.005 for the fixed ladder at this N is even worse than the reported full-
  run average (~11.7%) because the full run's larger budget gives the chains
  more time to drift apart and back; the mechanism is the same.
- The adaptive ladder lands in the healthy 20-40% band and the final ladder
  compresses to [1.00..1.32] - i.e. the correct ladder for this N is far
  narrower than anything a priori reasonable-looking. This is exactly why a
  per-combination adaptive ladder beats any single fixed choice.
- The edge pairs (0.08, 0.04) had not fully converged in this short test
  (300 burn rounds); the full run has ~10,000 burn rounds, so expect
  per-pair rates much closer to 0.234 uniformly. Check the printed per-pair
  rates in the full run.
- ESS(pred) improved 9 -> 70 but ESS(tau) stayed ~3: tau's autocorrelation
  is dominated by its own random-walk block, not by swap mixing. If tau ESS
  stays very low at full budget, that is a separate issue (tau step size /
  blocking), not a ladder problem.
- Coverage and RMSE are unchanged, as expected - this is a sampling-
  efficiency fix, not a model change.
