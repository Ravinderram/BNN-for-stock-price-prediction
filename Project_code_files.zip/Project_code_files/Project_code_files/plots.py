"""
plots.py
========
All figure generation. Every function takes already-computed results and
saves a PNG. No function trains a model or computes a metric; plotting is
strictly separated from computation.

Figures produced
----------------
Per stock per setup:
  forecast_{stock}_{setup}.png
  rmse_{stock}_{setup}.png
  calibration_{stock}_{setup}.png
  calibration_volatility_split_{stock}_{setup}.png
  volume_spikes_{stock}_{setup}.png
  combined_trace_{stock}_{setup}.png
  burnin_diagnostic_{stock}_{setup}.png
Per stock (global):
  volatility_intraday_{stock}.png
Cross-setup summary:
  calibration_combined_{setup}.png
  ece_heatmap.png
  ece_volatility_split.png
  setup_comparison_rmse.png
  coverage_comparison_all_models.png
  stocks_overview_compact.png
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates


LEVELS = [0.50, 0.70, 0.80, 0.90, 0.95, 0.99]

# Crisis windows for shading (start, end, colour, label).
# Boundaries match the test windows in data.get_experiment_splits() exactly:
# COVID = R1 test window (2020-02-01..2020-06-30, R2 is a subset),
# War = W1 test window, Middle East = M1 test window (M2 is a subset).
CRISIS_WINDOWS = [
    ("2020-02-01", "2020-06-30", "#9b59b6", "COVID-19"),
    ("2022-02-24", "2022-12-31", "#ff6b6b", "Russia-Ukraine War"),
    ("2025-06-01", "2026-05-31", "#ffa500", "Middle East Escalation"),
]

MODEL_COLORS = {
    "BNN": "#1f77b4",
    "FNN-Adam": "#ff7f0e",
    "FNN-SGD": "#2ca02c",
    "LSTM": "#9467bd",
    "MC-Dropout": "#d62728",
    "Bayes-LR": "#17becf",
}


def _ensure_dir(out_dir):
    os.makedirs(out_dir, exist_ok=True)


def _shade_crises(ax, date_index):
    """Shade crisis windows that overlap the plotted date range."""
    if len(date_index) == 0:
        return
    dmin = pd.Timestamp(min(date_index))
    dmax = pd.Timestamp(max(date_index))
    for start, end, color, label in CRISIS_WINDOWS:
        s = pd.Timestamp(start)
        e = pd.Timestamp(end)
        if e < dmin or s > dmax:
            continue
        ax.axvspan(max(s, dmin), min(e, dmax), color=color, alpha=0.15,
                   label=label)


# ----------------------------------------------------------------------------
# Forecast with intervals
# ----------------------------------------------------------------------------
def plot_forecast_with_intervals(test_dates, y_test, bnn_results, mc_results,
                                 stock_name, setup_name, out_dir):
    """Step-1 actual vs BNN mean with BNN and MC-Dropout 95% bands."""
    _ensure_dir(out_dir)
    dates = pd.to_datetime(list(test_dates))

    fig, ax = plt.subplots(figsize=(12, 5))

    actual = y_test[:, 0]
    ax.plot(dates, actual, color="black", lw=1.5, label="Actual", zorder=5)

    bnn_mean = bnn_results["pred"][:, 0]
    bnn_lo = bnn_results["fx_low_95"][:, 0]
    bnn_hi = bnn_results["fx_high_95"][:, 0]
    ax.plot(dates, bnn_mean, color=MODEL_COLORS["BNN"], lw=1.2,
            label="BNN mean")
    ax.fill_between(dates, bnn_lo, bnn_hi, color=MODEL_COLORS["BNN"],
                    alpha=0.20, label="BNN 95% PI")

    mc_lo = mc_results["fx_low_95"][:, 0]
    mc_hi = mc_results["fx_high_95"][:, 0]
    ax.fill_between(dates, mc_lo, mc_hi, color=MODEL_COLORS["MC-Dropout"],
                    alpha=0.15, label="MC-Dropout 95% PI")

    _shade_crises(ax, dates)

    ax.set_title(f"{stock_name} - {setup_name} - Step-1 forecast")
    ax.set_xlabel("Date")
    ax.set_ylabel("Normalised close price")
    ax.legend(loc="best", fontsize=8)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"forecast_{stock_name}_{setup_name}.png"),
                dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# RMSE bar chart
# ----------------------------------------------------------------------------
def plot_rmse_comparison(all_results, stock_name, setup_name, out_dir):
    """Grouped bar chart of RMSE per model per forecast step."""
    _ensure_dir(out_dir)
    models = [m for m in all_results if "rmse_per_step" in all_results[m]]
    # Keep only models with a full 5-step RMSE (exclude Bayes-LR step-1-only).
    models = [m for m in models if len(all_results[m]["rmse_per_step"]) == 5]

    n_steps = 5
    x = np.arange(n_steps)
    width = 0.8 / max(len(models), 1)

    fig, ax = plt.subplots(figsize=(10, 5))
    for i, m in enumerate(models):
        vals = all_results[m]["rmse_per_step"]
        ax.bar(x + i * width, vals, width,
               label=m, color=MODEL_COLORS.get(m, None))

    ax.set_xticks(x + width * (len(models) - 1) / 2)
    ax.set_xticklabels([f"Step {h+1}" for h in range(n_steps)])
    ax.set_ylabel("RMSE (normalised)")
    ax.set_title(f"{stock_name} - {setup_name} - RMSE by forecast step")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"rmse_{stock_name}_{setup_name}.png"),
                dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Calibration curves (one stock, one setup)
# ----------------------------------------------------------------------------
def plot_calibration_curves(calibration_results, stock_name, setup_name,
                            out_dir):
    """Calibration curves for whichever interval models are present.

    calibration_results : dict model_name -> calibration summary
        (as returned by calibration.calibration_summary).
    """
    _ensure_dir(out_dir)
    fig, ax = plt.subplots(figsize=(6.5, 6.5))

    # Diagonal reference.
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Perfect calibration")

    for model_name, summary in calibration_results.items():
        if summary is None:
            continue
        nominal = summary["levels"]
        observed = [summary["coverage_mean"][L] for L in nominal]
        ax.plot(nominal, observed, marker="o",
                color=MODEL_COLORS.get(model_name, None),
                label=f"{model_name} (ECE={summary['ece']:.3f})")

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Nominal confidence level")
    ax.set_ylabel("Observed coverage")
    ax.set_title(f"{stock_name} - {setup_name} - Calibration")
    ax.legend(loc="upper left", fontsize=8)
    ax.set_aspect("equal")
    fig.tight_layout()
    fig.savefig(
        os.path.join(out_dir, f"calibration_{stock_name}_{setup_name}.png"),
        dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Volatility-stratified calibration (low vs high vol, side by side)
# ----------------------------------------------------------------------------
def plot_calibration_volatility_split(split_results, stock_name, setup_name,
                                      out_dir):
    """Two side-by-side calibration charts: low-vol and high-vol days.

    split_results : dict model_name -> {'low_vol': summary, 'high_vol': summary}
    """
    _ensure_dir(out_dir)
    fig, axes = plt.subplots(1, 2, figsize=(13, 6))

    for ax, group, title in zip(
            axes, ["low_vol", "high_vol"],
            ["Low-volatility days", "High-volatility days"]):
        ax.plot([0, 1], [0, 1], "k--", lw=1, label="Perfect")
        for model_name, groups in split_results.items():
            summary = groups.get(group)
            if summary is None:
                continue
            nominal = summary["levels"]
            observed = [summary["coverage_mean"][L] for L in nominal]
            ax.plot(nominal, observed, marker="o",
                    color=MODEL_COLORS.get(model_name, None),
                    label=f"{model_name} (ECE={summary['ece']:.3f})")
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel("Nominal confidence level")
        ax.set_ylabel("Observed coverage")
        ax.set_title(title)
        ax.legend(loc="upper left", fontsize=8)
        ax.set_aspect("equal")

    fig.suptitle(f"{stock_name} - {setup_name} - "
                 f"Calibration by market volatility")
    fig.tight_layout()
    fig.savefig(os.path.join(
        out_dir, f"calibration_volatility_split_{stock_name}_{setup_name}.png"),
        dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Volume spikes
# ----------------------------------------------------------------------------
def plot_volume_spikes(vol_ratio_series, test_dates, spike_dates, bnn_errors,
                       stock_name, setup_name, out_dir):
    """Volume ratio across the test window with spike days marked.

    vol_ratio_series : pandas Series indexed by Date (full history).
    test_dates       : list of Timestamps for the test windows.
    spike_dates      : list/Index of Timestamps of the top spike days.
    bnn_errors       : array of step-1 BNN abs errors aligned with test_dates.
    """
    _ensure_dir(out_dir)
    dates = pd.to_datetime(list(test_dates))
    vr = vol_ratio_series.reindex(dates).values

    fig, ax1 = plt.subplots(figsize=(12, 5))
    ax1.bar(dates, vr, width=2.0, color="#9ecae1", label="Volume ratio")
    for sd in pd.to_datetime(list(spike_dates)):
        ax1.axvline(sd, color="red", ls="--", lw=0.8, alpha=0.7)
    ax1.set_xlabel("Date")
    ax1.set_ylabel("Volume / 20-day mean", color="#3182bd")
    ax1.tick_params(axis="y", labelcolor="#3182bd")

    ax2 = ax1.twinx()
    ax2.plot(dates, bnn_errors, color="black", lw=1.2,
             label="BNN step-1 abs error")
    ax2.set_ylabel("BNN step-1 abs error", color="black")

    ax1.set_title(f"{stock_name} - {setup_name} - "
                  f"Volume spikes vs BNN error")
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(os.path.join(
        out_dir, f"volume_spikes_{stock_name}_{setup_name}.png"), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Intraday volatility (per stock, full history)
# ----------------------------------------------------------------------------
def plot_volatility_intraday(df, stock_name, out_dir):
    """Two-panel: full close-price history and monthly mean intraday range."""
    _ensure_dir(out_dir)
    tmp = df.copy()
    tmp["intraday_range"] = (tmp["High"] - tmp["Low"]) / tmp["Close"]
    tmp = tmp.set_index("Date")

    monthly = tmp["intraday_range"].resample("ME").mean()
    overall_mean = tmp["intraday_range"].mean()

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(13, 8), sharex=True)

    ax1.plot(tmp.index, tmp["Close"], color="#1f77b4", lw=0.9)
    _shade_crises(ax1, tmp.index)
    ax1.set_ylabel("Close price")
    ax1.set_title(f"{stock_name} - price history")
    ax1.legend(loc="upper left", fontsize=8)

    ax2.bar(monthly.index, monthly.values, width=20, color="#6baed6")
    ax2.axhline(overall_mean, color="black", ls="--", lw=1,
                label=f"Overall mean ({overall_mean:.3f})")
    _shade_crises(ax2, monthly.index)
    ax2.set_ylabel("Monthly mean intraday range")
    ax2.set_xlabel("Date")
    ax2.set_title(f"{stock_name} - monthly intraday volatility")
    ax2.legend(loc="upper left", fontsize=8)

    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"volatility_intraday_{stock_name}.png"),
                dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Combined calibration across all stocks (one per setup)
# ----------------------------------------------------------------------------
def plot_calibration_combined(all_calibration_results, setup_name, out_dir):
    """Average coverage across all stocks for each model, one chart per setup.

    all_calibration_results : list of dicts, each model_name -> summary,
        one per stock.
    """
    _ensure_dir(out_dir)
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Perfect calibration")

    # Collect per-model coverage arrays across stocks.
    model_names = set()
    for res in all_calibration_results:
        model_names.update(res.keys())

    for model_name in sorted(model_names):
        curves = []
        eces = []
        for res in all_calibration_results:
            summary = res.get(model_name)
            if summary is None:
                continue
            curves.append([summary["coverage_mean"][L] for L in LEVELS])
            eces.append(summary["ece"])
        if not curves:
            continue
        mean_curve = np.mean(curves, axis=0)
        mean_ece = float(np.mean(eces))
        ax.plot(LEVELS, mean_curve, marker="o",
                color=MODEL_COLORS.get(model_name, None),
                label=f"{model_name} (ECE={mean_ece:.3f})")

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Nominal confidence level")
    ax.set_ylabel("Observed coverage (avg over stocks)")
    ax.set_title(f"{setup_name} - Combined calibration")
    ax.legend(loc="upper left", fontsize=8)
    ax.set_aspect("equal")
    fig.tight_layout()
    fig.savefig(
        os.path.join(out_dir, f"calibration_combined_{setup_name}.png"),
        dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# ECE heatmap
# ----------------------------------------------------------------------------
def plot_ece_heatmap(ece_table, out_dir):
    """Heatmap of ECE values.

    ece_table : DataFrame with index = model, columns = '{stock}_{setup}'.
    """
    _ensure_dir(out_dir)
    fig, ax = plt.subplots(figsize=(max(8, ece_table.shape[1] * 0.5),
                                    max(3, ece_table.shape[0] * 0.6)))
    data = ece_table.values.astype(float)
    im = ax.imshow(data, aspect="auto", cmap="YlOrRd", vmin=0,
                   vmax=np.nanmax(data) if np.isfinite(np.nanmax(data)) else 1)

    ax.set_xticks(range(ece_table.shape[1]))
    ax.set_xticklabels(ece_table.columns, rotation=90, fontsize=7)
    ax.set_yticks(range(ece_table.shape[0]))
    ax.set_yticklabels(ece_table.index, fontsize=9)

    # Annotate cells.
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            if np.isfinite(data[i, j]):
                ax.text(j, i, f"{data[i, j]:.2f}", ha="center", va="center",
                        fontsize=6,
                        color="black" if data[i, j] < 0.4 else "white")

    fig.colorbar(im, ax=ax, label="ECE")
    ax.set_title("Expected Calibration Error across experiments")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "ece_heatmap.png"), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# ECE volatility split bar chart
# ----------------------------------------------------------------------------
def plot_ece_volatility_split(ece_df, out_dir):
    """Grouped bars comparing low/high-vol ECE for BNN and MC-Dropout.

    ece_df : DataFrame with columns
        stock, setup, model, ece_low_vol, ece_high_vol, ece_overall
    Averaged across stocks for each setup and model.
    """
    _ensure_dir(out_dir)
    grp = (ece_df.groupby(["setup", "model"])[["ece_low_vol", "ece_high_vol"]]
           .mean().reset_index())

    setups = sorted(grp["setup"].unique())
    models = sorted(grp["model"].unique())

    # Build bar groups: for each setup, 4 bars (model x {low, high}).
    n_groups = len(setups)
    bars_per_group = len(models) * 2
    width = 0.8 / max(bars_per_group, 1)

    fig, ax = plt.subplots(figsize=(max(8, n_groups * 2.0), 5))
    x = np.arange(n_groups)

    bar_idx = 0
    for m in models:
        lows = []
        highs = []
        for s in setups:
            row = grp[(grp["setup"] == s) & (grp["model"] == m)]
            lows.append(row["ece_low_vol"].values[0] if len(row) else np.nan)
            highs.append(row["ece_high_vol"].values[0] if len(row) else np.nan)
        ax.bar(x + bar_idx * width, lows, width,
               label=f"{m} low-vol")
        bar_idx += 1
        ax.bar(x + bar_idx * width, highs, width,
               label=f"{m} high-vol")
        bar_idx += 1

    ax.set_xticks(x + width * (bars_per_group - 1) / 2)
    ax.set_xticklabels(setups)
    ax.set_ylabel("ECE")
    ax.set_title("ECE on low- vs high-volatility days (avg over stocks)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "ece_volatility_split.png"), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Setup comparison (BNN RMSE averaged over stocks)
# ----------------------------------------------------------------------------
def plot_setup_comparison_rmse(summary_df, out_dir):
    """BNN RMSE per step averaged over stocks, grouped by setup.

    summary_df : the full summary DataFrame (one row per stock/setup/model).
    """
    _ensure_dir(out_dir)
    bnn = summary_df[summary_df["model"] == "BNN"]
    setups = sorted(bnn["setup"].unique())
    step_cols = [f"rmse_step{h+1}" for h in range(5)]

    n_steps = 5
    x = np.arange(n_steps)
    width = 0.8 / max(len(setups), 1)

    fig, ax = plt.subplots(figsize=(10, 5))
    for i, s in enumerate(setups):
        rows = bnn[bnn["setup"] == s]
        means = [rows[c].mean() for c in step_cols]
        ax.bar(x + i * width, means, width, label=s)

    ax.set_xticks(x + width * (len(setups) - 1) / 2)
    ax.set_xticklabels([f"Step {h+1}" for h in range(n_steps)])
    ax.set_ylabel("BNN RMSE (avg over stocks)")
    ax.set_title("BNN RMSE by forecast step across setups")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "setup_comparison_rmse.png"), dpi=120)
    plt.close(fig)


# ============================================================================
# PRESENTATION-FOCUSED PLOTS
# Extra figures aimed at explaining the project to a classroom audience.
# Produced by run.py after the main results are collected.
# ============================================================================

def plot_concept_point_vs_distribution(out_dir):
    """Teaching figure: why a Bayesian model gives a range, not one number."""
    _ensure_dir(out_dir)
    rng = np.random.RandomState(0)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    ax1.axvline(100, color=MODEL_COLORS["FNN-Adam"], lw=2.5,
                label="Predicted price")
    ax1.axvline(103, color="black", lw=2.0, ls="--", label="True price")
    ax1.set_xlim(90, 115)
    ax1.set_ylim(0, 1)
    ax1.set_yticks([])
    ax1.set_xlabel("Price")
    ax1.set_title("Standard neural network\nOne number, no uncertainty",
                  fontsize=12)
    ax1.legend(loc="upper right", fontsize=9)

    samples = rng.normal(100, 4, 5000)
    ax2.hist(samples, bins=50, color=MODEL_COLORS["BNN"], alpha=0.55,
             density=True, label="Predicted distribution")
    lo, hi = np.percentile(samples, [2.5, 97.5])
    ax2.axvspan(lo, hi, color=MODEL_COLORS["BNN"], alpha=0.12,
                label="95% credible interval")
    ax2.axvline(samples.mean(), color=MODEL_COLORS["BNN"], lw=2,
                label="Mean prediction")
    ax2.axvline(103, color="black", lw=2.0, ls="--", label="True price")
    ax2.set_xlim(90, 115)
    ax2.set_yticks([])
    ax2.set_xlabel("Price")
    ax2.set_title("Bayesian neural network\nA full distribution with uncertainty",
                  fontsize=12)
    ax2.legend(loc="upper right", fontsize=9)

    fig.suptitle("Why we use a Bayesian neural network", fontsize=14)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "concept_point_vs_distribution.png"),
                dpi=120)
    plt.close(fig)


def plot_concept_calibration_explained(out_dir):
    """Teaching figure: how to read a calibration curve."""
    _ensure_dir(out_dir)
    levels = np.array([0.50, 0.70, 0.80, 0.90, 0.95, 0.99])
    fig, ax = plt.subplots(figsize=(7.5, 7.5))
    ax.plot([0, 1], [0, 1], "k--", lw=1.5, label="Perfect calibration")

    overconfident = np.clip(levels - 0.28, 0, 1)
    underconfident = np.clip(levels + 0.15, 0, 1)
    ax.plot(levels, overconfident, marker="o", color="#d62728", lw=2,
            label="Overconfident (intervals too narrow)")
    ax.plot(levels, underconfident, marker="o", color="#1f77b4", lw=2,
            label="Underconfident (intervals too wide)")

    ax.annotate("Below the line:\nmodel is too sure of itself",
                xy=(0.8, 0.52), xytext=(0.45, 0.30),
                fontsize=10, color="#d62728",
                arrowprops=dict(arrowstyle="->", color="#d62728"))
    ax.annotate("Above the line:\nmodel is too cautious",
                xy=(0.7, 0.85), xytext=(0.05, 0.80),
                fontsize=10, color="#1f77b4",
                arrowprops=dict(arrowstyle="->", color="#1f77b4"))

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("What the model claims (nominal confidence)", fontsize=11)
    ax.set_ylabel("What actually happens (observed coverage)", fontsize=11)
    ax.set_title("How to read a calibration curve", fontsize=13)
    ax.legend(loc="lower right", fontsize=9)
    ax.set_aspect("equal")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "concept_calibration_explained.png"),
                dpi=120)
    plt.close(fig)


def plot_ece_ranking(summary_df, out_dir):
    """Horizontal bar chart ranking models by average ECE (lower = better)."""
    _ensure_dir(out_dir)
    sub = summary_df[summary_df["ece"].notna()]
    if sub.empty:
        return
    means = sub.groupby("model")["ece"].mean().sort_values()
    fig, ax = plt.subplots(figsize=(8, 4))
    colors = [MODEL_COLORS.get(m, "#888") for m in means.index]
    bars = ax.barh(means.index, means.values, color=colors)
    for bar, v in zip(bars, means.values):
        ax.text(v + 0.005, bar.get_y() + bar.get_height() / 2,
                f"{v:.3f}", va="center", fontsize=10)
    ax.set_xlabel("Expected Calibration Error (lower is better)")
    ax.set_title("Which model has the most trustworthy uncertainty?")
    ax.invert_yaxis()
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "ece_ranking.png"), dpi=120)
    plt.close(fig)


def plot_accuracy_vs_calibration(summary_df, out_dir):
    """Scatter of RMSE (accuracy) vs ECE (calibration) for interval models."""
    _ensure_dir(out_dir)
    sub = summary_df[summary_df["ece"].notna()]
    if sub.empty:
        return
    agg = sub.groupby("model").agg(
        rmse=("rmse_overall", "mean"),
        ece=("ece", "mean")).reset_index()

    fig, ax = plt.subplots(figsize=(8, 6.5))
    for _, row in agg.iterrows():
        ax.scatter(row["rmse"], row["ece"], s=220,
                   color=MODEL_COLORS.get(row["model"], "#888"),
                   edgecolor="black", zorder=3)
        ax.annotate(row["model"], (row["rmse"], row["ece"]),
                    xytext=(8, 8), textcoords="offset points", fontsize=11)
    ax.set_xlabel("RMSE  (prediction error - lower is better)", fontsize=11)
    ax.set_ylabel("ECE  (calibration error - lower is better)", fontsize=11)
    ax.set_title("Accuracy vs Calibration\nThe best model is in the "
                 "bottom-left corner", fontsize=12)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "accuracy_vs_calibration.png"), dpi=120)
    plt.close(fig)


def plot_fan_chart(test_dates, y_test, bnn_samples, stock_name, setup_name,
                   out_dir):
    """Nested credible-interval 'fan' for the BNN step-1 forecast."""
    _ensure_dir(out_dir)
    dates = pd.to_datetime(list(test_dates))
    s = bnn_samples[:, :, 0]
    median = np.percentile(s, 50, axis=0)
    bands = [(25, 75, 0.35, "50% band"),
             (10, 90, 0.22, "80% band"),
             (2.5, 97.5, 0.12, "95% band")]

    fig, ax = plt.subplots(figsize=(12, 5.5))
    for lo, hi, alpha, label in bands:
        ax.fill_between(dates,
                        np.percentile(s, lo, axis=0),
                        np.percentile(s, hi, axis=0),
                        color=MODEL_COLORS["BNN"], alpha=alpha, label=label)
    ax.plot(dates, median, color=MODEL_COLORS["BNN"], lw=1.3, label="BNN median")
    ax.plot(dates, y_test[:, 0], color="black", lw=1.4, label="Actual")
    _shade_crises(ax, dates)
    ax.set_title(f"{stock_name} - {setup_name} - BNN forecast fan chart")
    ax.set_xlabel("Date")
    ax.set_ylabel("Normalised close price")
    ax.legend(loc="best", fontsize=8)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"fan_chart_{stock_name}_{setup_name}.png"),
                dpi=120)
    plt.close(fig)


def plot_multistep_forecast(test_dates, y_test, model_results, model_name,
                            stock_name, setup_name, out_dir):
    """One panel per forecast horizon for a single interval-producing model.

    Addresses the point that the model forecasts 5 days ahead but only the
    1-day-ahead horizon was ever plotted. Each panel shows the actual price,
    the posterior-mean prediction and the 95% interval for that horizon, so
    the growth of both error and interval width with forecast distance is
    directly visible instead of only appearing in a table of numbers.
    """
    _ensure_dir(out_dir)
    dates = pd.to_datetime(list(test_dates))
    pred = np.asarray(model_results["pred"])
    lo = np.asarray(model_results["fx_low_95"])
    hi = np.asarray(model_results["fx_high_95"])
    H = pred.shape[1]
    color = MODEL_COLORS.get(model_name, "#1f77b4")

    fig, axes = plt.subplots(H, 1, figsize=(12, 2.6 * H), sharex=True)
    if H == 1:
        axes = [axes]

    for h in range(H):
        ax = axes[h]
        actual_h = y_test[:, h]
        ax.plot(dates, actual_h, color="black", lw=1.3, label="Actual",
                zorder=5)
        ax.plot(dates, pred[:, h], color=color, lw=1.2,
                label=f"{model_name} mean")
        ax.fill_between(dates, lo[:, h], hi[:, h], color=color, alpha=0.20,
                        label="95% interval")

        rmse_h = float(np.sqrt(np.mean((actual_h - pred[:, h]) ** 2)))
        width_h = float(np.mean(hi[:, h] - lo[:, h]))
        inside = ((actual_h >= lo[:, h]) & (actual_h <= hi[:, h])).mean()
        ax.set_title(
            f"Step {h + 1} ({h + 1}-day ahead)   "
            f"RMSE={rmse_h:.4f}   mean 95% width={width_h:.4f}   "
            f"coverage@95={inside * 100:.1f}%",
            fontsize=10)
        ax.set_ylabel("Norm. close")
        if h == 0:
            ax.legend(loc="best", fontsize=8)

    axes[-1].set_xlabel("Date")
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    fig.suptitle(
        f"{stock_name} - {setup_name} - {model_name} forecasts at all "
        f"{H} horizons", fontsize=13, y=0.995)
    fig.autofmt_xdate()
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    fig.savefig(
        os.path.join(out_dir,
                     f"multistep_{model_name}_{stock_name}_{setup_name}.png"),
        dpi=120)
    plt.close(fig)


def plot_multistep_fan_chart(test_dates, y_test, samples, model_name,
                             stock_name, setup_name, out_dir):
    """Nested credible-interval fan chart, one panel per forecast horizon.

    Same idea as plot_fan_chart but repeated across horizons, so the fan can
    be seen widening as the forecast reaches further into the future.
    """
    _ensure_dir(out_dir)
    dates = pd.to_datetime(list(test_dates))
    samples = np.asarray(samples)
    H = samples.shape[2]
    color = MODEL_COLORS.get(model_name, "#1f77b4")
    bands = [(25, 75, 0.35, "50% band"),
             (10, 90, 0.22, "80% band"),
             (2.5, 97.5, 0.12, "95% band")]

    fig, axes = plt.subplots(H, 1, figsize=(12, 2.6 * H), sharex=True)
    if H == 1:
        axes = [axes]

    for h in range(H):
        ax = axes[h]
        s = samples[:, :, h]
        for lo_p, hi_p, alpha, label in bands:
            ax.fill_between(dates,
                            np.percentile(s, lo_p, axis=0),
                            np.percentile(s, hi_p, axis=0),
                            color=color, alpha=alpha,
                            label=label if h == 0 else None)
        ax.plot(dates, np.percentile(s, 50, axis=0), color=color, lw=1.2,
                label=f"{model_name} median" if h == 0 else None)
        ax.plot(dates, y_test[:, h], color="black", lw=1.3,
                label="Actual" if h == 0 else None)

        width_h = float(np.mean(np.percentile(s, 97.5, axis=0)
                                - np.percentile(s, 2.5, axis=0)))
        ax.set_title(f"Step {h + 1} ({h + 1}-day ahead)   "
                     f"mean 95% width={width_h:.4f}", fontsize=10)
        ax.set_ylabel("Norm. close")
        if h == 0:
            ax.legend(loc="best", fontsize=8)

    axes[-1].set_xlabel("Date")
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    fig.suptitle(
        f"{stock_name} - {setup_name} - {model_name} fan chart at all "
        f"{H} horizons", fontsize=13, y=0.995)
    fig.autofmt_xdate()
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    fig.savefig(
        os.path.join(
            out_dir,
            f"multistep_fan_{model_name}_{stock_name}_{setup_name}.png"),
        dpi=120)
    plt.close(fig)


def plot_calibration_grid(grid_results, setup_name, out_dir):
    """Grid of calibration curves, one panel per stock, for a given setup."""
    _ensure_dir(out_dir)
    stocks = list(grid_results.keys())
    n = len(stocks)
    if n == 0:
        return
    ncols = 2
    nrows = (n + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(11, 5 * nrows))
    axes = np.array(axes).reshape(-1)

    for ax, stock in zip(axes, stocks):
        ax.plot([0, 1], [0, 1], "k--", lw=1)
        for model_name, summary in grid_results[stock].items():
            if summary is None:
                continue
            nominal = summary["levels"]
            observed = [summary["coverage_mean"][L] for L in nominal]
            ax.plot(nominal, observed, marker="o", ms=4,
                    color=MODEL_COLORS.get(model_name, None),
                    label=f"{model_name} ({summary['ece']:.2f})")
        ax.set_title(stock, fontsize=11)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_aspect("equal")
        ax.legend(fontsize=7, loc="upper left")
        ax.set_xlabel("Nominal")
        ax.set_ylabel("Observed")
    for ax in axes[len(stocks):]:
        ax.axis("off")

    fig.suptitle(f"Calibration across all stocks - {setup_name}", fontsize=13)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"calibration_grid_{setup_name}.png"),
                dpi=120)
    plt.close(fig)


def plot_mcmc_trace(bnn_results, stock_name, setup_name, out_dir):
    """Trace + histogram of the posterior prediction at the first test point."""
    _ensure_dir(out_dir)
    samples = bnn_results.get("samples")
    if samples is None:
        return
    trace = samples[:, 0, 0]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4),
                                   gridspec_kw={"width_ratios": [3, 1]})
    ax1.plot(trace, color=MODEL_COLORS["BNN"], lw=0.6)
    ax1.set_xlabel("Posterior sample index")
    ax1.set_ylabel("Predicted value (first test point)")
    ax1.set_title(f"{stock_name} - {setup_name} - MCMC trace")
    ax2.hist(trace, bins=40, orientation="horizontal",
             color=MODEL_COLORS["BNN"], alpha=0.6)
    ax2.set_xlabel("Frequency")
    ax2.set_title("Distribution")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"mcmc_trace_{stock_name}_{setup_name}.png"),
                dpi=120)
    plt.close(fig)


def plot_crisis_coverage_comparison(summary_df, out_dir):
    """Bar chart comparing BNN 95% coverage across setups, grouped by crisis."""
    _ensure_dir(out_dir)
    bnn = summary_df[(summary_df["model"] == "BNN")
                     & (summary_df["coverage_95"].notna())]
    if bnn.empty:
        return
    grp = bnn.groupby("setup")["coverage_95"].mean()
    setup_colors = {"R1": "#8da0cb", "R2": "#8da0cb",
                    "W1": "#fc8d62", "W2": "#fc8d62",
                    "M1": "#66c2a5", "M2": "#66c2a5"}
    order = [s for s in ["R1", "R2", "W1", "W2", "M1", "M2"] if s in grp.index]
    vals = [grp[s] for s in order]
    colors = [setup_colors.get(s, "#888") for s in order]

    fig, ax = plt.subplots(figsize=(9, 5))
    bars = ax.bar(order, vals, color=colors)
    ax.axhline(0.95, color="red", ls="--", lw=1.5)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width() / 2, v + 0.01,
                f"{v:.0%}", ha="center", fontsize=10)
    from matplotlib.patches import Patch
    legend_items = [
        Patch(color="#8da0cb", label="R = COVID-19"),
        Patch(color="#fc8d62", label="W = Russia-Ukraine"),
        Patch(color="#66c2a5", label="M = Middle East"),
        plt.Line2D([0], [0], color="red", ls="--", label="Target (95%)"),
    ]
    ax.legend(handles=legend_items, fontsize=9, loc="lower right")
    ax.set_ylabel("BNN observed coverage at 95% level")
    ax.set_ylim(0, 1.05)
    ax.set_title("Does calibration depend on the type of crisis?")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "crisis_coverage_comparison.png"), dpi=120)
    plt.close(fig)


def plot_summary_dashboard(summary_df, out_dir):
    """Single overview figure combining the four headline results."""
    _ensure_dir(out_dir)
    if summary_df.empty:
        return
    fig, axes = plt.subplots(2, 2, figsize=(14, 11))

    axA = axes[0, 0]
    rmse_by_model = summary_df.groupby("model")["rmse_overall"].mean().sort_values()
    axA.barh(rmse_by_model.index, rmse_by_model.values,
             color=[MODEL_COLORS.get(m, "#888") for m in rmse_by_model.index])
    axA.set_title("A. Prediction accuracy (RMSE, lower is better)")
    axA.set_xlabel("RMSE")
    axA.invert_yaxis()

    axB = axes[0, 1]
    sub = summary_df[summary_df["ece"].notna()]
    if not sub.empty:
        ece_by_model = sub.groupby("model")["ece"].mean().sort_values()
        axB.barh(ece_by_model.index, ece_by_model.values,
                 color=[MODEL_COLORS.get(m, "#888") for m in ece_by_model.index])
        for i, v in enumerate(ece_by_model.values):
            axB.text(v + 0.005, i, f"{v:.3f}", va="center", fontsize=9)
    axB.set_title("B. Calibration quality (ECE, lower is better)")
    axB.set_xlabel("ECE")
    axB.invert_yaxis()

    axC = axes[1, 0]
    if not sub.empty:
        agg = sub.groupby("model").agg(
            rmse=("rmse_overall", "mean"), ece=("ece", "mean")).reset_index()
        for _, row in agg.iterrows():
            axC.scatter(row["rmse"], row["ece"], s=180,
                        color=MODEL_COLORS.get(row["model"], "#888"),
                        edgecolor="black", zorder=3)
            axC.annotate(row["model"], (row["rmse"], row["ece"]),
                         xytext=(6, 6), textcoords="offset points", fontsize=9)
    axC.set_title("C. Accuracy vs Calibration (ideal = bottom-left)")
    axC.set_xlabel("RMSE")
    axC.set_ylabel("ECE")
    axC.grid(alpha=0.3)

    axD = axes[1, 1]
    bnn = summary_df[(summary_df["model"] == "BNN")
                     & (summary_df["coverage_95"].notna())]
    if not bnn.empty:
        grp = bnn.groupby("setup")["coverage_95"].mean()
        order = [s for s in ["R1", "R2", "W1", "W2", "M1", "M2"]
                 if s in grp.index]
        axD.bar(order, [grp[s] for s in order], color="#4c72b0")
        axD.axhline(0.95, color="red", ls="--", lw=1.5, label="Target")
        axD.legend(fontsize=9)
    axD.set_title("D. BNN coverage at 95% by setup")
    axD.set_ylabel("Observed coverage")
    axD.set_ylim(0, 1.05)

    fig.suptitle("Project results at a glance", fontsize=15, y=1.0)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "summary_dashboard.png"), dpi=120)
    plt.close(fig)


def plot_recalibration(recalib_results, stock_name, setup_name, out_dir):
    """Before/after calibration curves from temperature scaling.

    recalib_results : dict model_name -> {T, before, after, ece_before, ece_after}
        where 'before' and 'after' are calibration summaries.

    Shows, for each recalibrated model, the raw (overconfident) curve and the
    temperature-scaled curve, both against the diagonal. This is the
    "we found the problem AND fixed it" figure.
    """
    _ensure_dir(out_dir)
    models = [m for m in recalib_results if recalib_results[m] is not None]
    if not models:
        return

    n = len(models)
    fig, axes = plt.subplots(1, n, figsize=(6.5 * n, 6))
    if n == 1:
        axes = [axes]

    for ax, m in zip(axes, models):
        rec = recalib_results[m]
        before = rec["before"]
        after = rec["after"]
        levels = before["levels"]

        ax.plot([0, 1], [0, 1], "k--", lw=1.5, label="Perfect calibration")
        ax.plot(levels, [before["coverage_mean"][L] for L in levels],
                marker="o", color="#d62728", lw=2,
                label=f"Before (ECE={rec['ece_before']:.3f})")
        ax.plot(levels, [after["coverage_mean"][L] for L in levels],
                marker="s", color="#2ca02c", lw=2,
                label=f"After T={rec['T']:.2f} (ECE={rec['ece_after']:.3f})")

        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_aspect("equal")
        ax.set_xlabel("Nominal confidence level")
        ax.set_ylabel("Observed coverage")
        ax.set_title(f"{m}")
        ax.legend(loc="upper left", fontsize=9)

    fig.suptitle(f"{stock_name} - {setup_name} - "
                 f"Temperature-scaling recalibration", fontsize=13)
    fig.tight_layout()
    fig.savefig(os.path.join(
        out_dir, f"recalibration_{stock_name}_{setup_name}.png"), dpi=120)
    plt.close(fig)


def plot_recalibration_summary(recalib_rows, out_dir):
    """Bar chart of ECE before vs after recalibration, averaged over runs.

    recalib_rows : list of dicts with keys stock, setup, model, ece_before,
                   ece_after.
    """
    _ensure_dir(out_dir)
    if not recalib_rows:
        return
    df = pd.DataFrame(recalib_rows)
    agg = df.groupby("model")[["ece_before", "ece_after"]].mean()
    if agg.empty:
        return

    models = list(agg.index)
    x = np.arange(len(models))
    width = 0.35

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - width / 2, agg["ece_before"], width, label="Before",
           color="#d62728")
    ax.bar(x + width / 2, agg["ece_after"], width, label="After (recalibrated)",
           color="#2ca02c")
    for i, m in enumerate(models):
        ax.text(i - width / 2, agg["ece_before"][m] + 0.005,
                f"{agg['ece_before'][m]:.3f}", ha="center", fontsize=9)
        ax.text(i + width / 2, agg["ece_after"][m] + 0.005,
                f"{agg['ece_after'][m]:.3f}", ha="center", fontsize=9)

    ax.set_xticks(x)
    ax.set_xticklabels(models)
    ax.set_ylabel("Expected Calibration Error")
    ax.set_title("Temperature scaling: ECE before vs after "
                 "(averaged over all runs)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "recalibration_summary.png"), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Task 1: combined trace plot - BNN, MC-Dropout, Bayes-LR on one figure
# ----------------------------------------------------------------------------
def plot_combined_model_traces(bnn_trace, mcdropout_trace, bayeslr_trace,
                               stock_name, setup_name, out_dir):
    """Overlay the three models' sample sequences at the first test point.

    Terminology: BNN and Bayes-LR are genuine MCMC (each value is one MCMC
    step; the sequence has autocorrelation and, for the BNN, burn-in
    structure). MC-Dropout is NOT MCMC - it performs repeated independent
    stochastic forward passes with dropout active (no chain, no burn-in, no
    autocorrelation). The legend labels reflect this so the figure is not
    misleading.

    Parameters
    ----------
    bnn_trace, mcdropout_trace, bayeslr_trace : 1-D arrays of the predicted
        value at the first test point (first forecast step). bayeslr_trace
        may be None if the PyMC reference was skipped.
    """
    _ensure_dir(out_dir)
    series = [
        ("BNN (MCMC)", bnn_trace, MODEL_COLORS["BNN"]),
        ("MC-Dropout (forward passes)", mcdropout_trace,
         MODEL_COLORS["MC-Dropout"]),
        ("Bayes-LR (MCMC)", bayeslr_trace, MODEL_COLORS["Bayes-LR"]),
    ]
    series = [(lbl, np.asarray(t).ravel(), c)
              for lbl, t, c in series if t is not None]
    if not series:
        return

    # All three quantities live in the same normalised-price space (predicted
    # value at the same test point), so one shared panel works; each series
    # is plotted against its own sample index since lengths differ.
    fig, ax = plt.subplots(figsize=(12, 4.5))
    for lbl, t, c in series:
        ax.plot(np.arange(len(t)), t, color=c, lw=0.7, alpha=0.85, label=lbl)
    ax.set_xlabel("Sample index (MCMC step / forward-pass number)")
    ax.set_ylabel("Predicted value (first test point, step 1)")
    ax.set_title(f"{stock_name} - {setup_name} - "
                 "posterior samples at the first test point, all models")
    ax.legend(fontsize=9, loc="best")
    fig.tight_layout()
    fig.savefig(os.path.join(
        out_dir, f"combined_trace_{stock_name}_{setup_name}.png"), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Task 2: burn-in stabilisation diagnostic (BNN cold chain only)
# ----------------------------------------------------------------------------
def plot_burnin_diagnostic(burnin_diag, stock_name, setup_name, out_dir):
    """Where does the BNN cold chain actually stabilise vs the config cut?

    burnin_diag : dict from bnn.run_bnn()["burnin_diag"] with keys
        trace      : 1-D array, predicted value at the first test point over
                     the FULL chain (pre- and post-burn-in), possibly thinned
        indices    : original step index of each trace entry
        burn_index : configured burn-in cut in original step units
        n_total    : total number of saved cold-chain steps

    The plot shows the raw trace (semi-transparent), its running mean, a
    vertical line at the empirically-detected stabilisation point (where the
    running mean has settled to within a tolerance of its final value and
    stays there), and a second vertical line at the configured burn-in cut,
    so the two can be compared visually.
    """
    _ensure_dir(out_dir)
    if not burnin_diag:
        return
    trace = np.asarray(burnin_diag["trace"], dtype=float).ravel()
    indices = np.asarray(burnin_diag["indices"]).ravel()
    burn_index = int(burnin_diag["burn_index"])
    n_total = int(burnin_diag.get("n_total", indices[-1] + 1))
    if len(trace) < 10:
        return

    run_mean = np.cumsum(trace) / np.arange(1, len(trace) + 1)

    # Empirical stabilisation point: the first index after which the running
    # mean stays within `tol` of its final value. tol is a quarter of the
    # trace's standard deviation over the final 25% (the presumed stationary
    # part), i.e. the running mean must have settled well inside the
    # stationary fluctuation band.
    tail = trace[int(0.75 * len(trace)):]
    tol = max(float(np.std(tail)) * 0.25, 1e-12)
    dev = np.abs(run_mean - run_mean[-1])
    above = np.where(dev > tol)[0]
    stab_i = int(above[-1]) + 1 if len(above) else 0
    stab_i = min(stab_i, len(indices) - 1)
    stab_step = int(indices[stab_i])

    fig, ax = plt.subplots(figsize=(12, 4.5))
    ax.plot(indices, trace, color=MODEL_COLORS["BNN"], lw=0.5, alpha=0.30,
            label="Raw trace (pred. at first test point)")
    ax.plot(indices, run_mean, color="#222222", lw=1.8,
            label="Running mean")
    ax.axvline(stab_step, color="#2ca02c", lw=1.8,
               label=f"Empirical stabilisation (~step {stab_step:,})")
    ax.axvline(burn_index, color="red", ls="--", lw=1.8,
               label=f"Configured burn-in cut ({burn_index:,} = "
                     f"{burn_index / max(n_total, 1):.0%})")
    ax.set_xlabel("Cold-chain sample index (0 .. n_samples)")
    ax.set_ylabel("Predicted value (first test point)")
    ax.set_title(f"{stock_name} - {setup_name} - "
                 "burn-in stabilisation diagnostic (BNN cold chain)")
    ax.legend(fontsize=9, loc="best")
    fig.tight_layout()
    fig.savefig(os.path.join(
        out_dir, f"burnin_diagnostic_{stock_name}_{setup_name}.png"), dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Task 4: grouped bars - which models reach the 95% coverage target?
# ----------------------------------------------------------------------------
def plot_coverage_comparison_all_models(summary_df, out_dir):
    """Grouped bar chart of observed coverage@95 per setup for all 3 models.

    Extends the BNN-only crisis_coverage_comparison figure: for each setup
    (R1..M2) three adjacent bars (BNN, MC-Dropout, Bayes-LR), averaged across
    the 4 stocks, with the 95% target line. Crisis-type colouring is dropped
    since crisis type is now the x-axis grouping; each model keeps one
    consistent colour across all setups.
    """
    _ensure_dir(out_dir)
    models = ["BNN", "MC-Dropout", "Bayes-LR"]
    df = summary_df[(summary_df["model"].isin(models))
                    & (summary_df["coverage_95"].notna())]
    if df.empty:
        return

    grp = df.groupby(["setup", "model"])["coverage_95"].mean()
    order = [s for s in ["R1", "R2", "W1", "W2", "M1", "M2"]
             if s in df["setup"].unique()]
    present = [m for m in models if m in df["model"].unique()]

    x = np.arange(len(order))
    width = 0.8 / max(len(present), 1)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    for j, m in enumerate(present):
        offs = (j - (len(present) - 1) / 2) * width
        vals = [grp.get((s, m), np.nan) for s in order]
        bars = ax.bar(x + offs, vals, width * 0.92, label=m,
                      color=MODEL_COLORS.get(m, "#888888"))
        for bar, v in zip(bars, vals):
            if np.isfinite(v):
                ax.text(bar.get_x() + bar.get_width() / 2, v + 0.012,
                        f"{v * 100:.1f}%", ha="center", fontsize=8.5)

    ax.axhline(0.95, color="red", ls="--", lw=1.5, label="Target (95%)")
    ax.set_xticks(x)
    ax.set_xticklabels(order)
    ax.set_xlabel("Setup")
    ax.set_ylabel("Observed coverage at the 95% nominal level")
    ax.set_ylim(0, 1.10)
    ax.set_title("Which models reach the 95% coverage target? "
                 "(mean over 4 stocks)")
    ax.legend(fontsize=9, loc="lower right", ncol=2)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "coverage_comparison_all_models.png"),
                dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Task 5: compact multi-stock overview (for presentation use)
# ----------------------------------------------------------------------------
STOCK_DISPLAY = {
    "MMM": ("MMM (US)", "#4C72B0"),
    "CBA_AX": ("CBA.AX (Australia)", "#DD8452"),
    "DAI_DE": ("DAI.DE (Germany)", "#55A868"),
    "SS_600118": ("600118.SS (China)", "#C44E52"),
}


def plot_stocks_overview_compact(stocks, crisis_windows, out_dir):
    """Single presentation plot: all 4 stocks normalised on one axis.

    Parameters
    ----------
    stocks : dict of stock_key -> DataFrame with Date and Close columns.
    crisis_windows : list of (start, end, label) tuples. Pass windows built
        from data.get_experiment_splits() so the shading uses the project's
        EXACT R1/W1/M1 test boundaries (R2/W2/M2 are subsets), not
        approximate public crisis dates.
    """
    _ensure_dir(out_dir)

    rc = {
        "figure.dpi": 200, "font.size": 12, "axes.titlesize": 17,
        "axes.titleweight": "bold", "axes.labelsize": 12,
        "legend.fontsize": 11,
    }
    with plt.style.context("seaborn-v0_8-whitegrid"), plt.rc_context(rc):
        fig, ax = plt.subplots(figsize=(13, 7))

        ymax = 0.0
        year_min, year_max = None, None
        for key, df in stocks.items():
            name, color = STOCK_DISPLAY.get(key, (key, "#888888"))
            d = (df.dropna(subset=["Close"])
                   .set_index("Date")["Close"])
            d_weekly = d.resample("W").last().dropna()  # smooth for clarity
            if len(d_weekly) == 0:
                continue
            indexed = d_weekly / d_weekly.iloc[0] * 100  # start = 100
            ax.plot(indexed.index, indexed.values, label=name, color=color,
                    linewidth=2.0, alpha=0.92, solid_capstyle="round")
            ymax = max(ymax, float(indexed.max()))
            y0, y1 = indexed.index[0].year, indexed.index[-1].year
            year_min = y0 if year_min is None else min(year_min, y0)
            year_max = y1 if year_max is None else max(year_max, y1)

        ymax = ymax * 1.15 if ymax > 0 else 100.0

        for start, end, label in crisis_windows:
            s, e = pd.Timestamp(start), pd.Timestamp(end)
            ax.axvspan(s, e, color="#555555", alpha=0.10, zorder=0)
            mid = s + (e - s) / 2
            ax.annotate(label, xy=(mid, ymax * 0.965), ha="center", va="top",
                        fontsize=9.5, fontweight="bold", color="#333333",
                        linespacing=1.3,
                        bbox=dict(boxstyle="round,pad=0.35", fc="white",
                                  ec="#aaaaaa", alpha=0.9))

        ax.set_ylim(0, ymax)
        title_years = (f" ({year_min}\u2013{year_max})"
                       if year_min is not None else "")
        ax.set_title("Stock Performance Through Global Crisis Periods"
                     + title_years, pad=16)
        ax.set_ylabel("Normalized price (start = 100)")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.legend(loc="upper left", frameon=True, framealpha=0.95,
                  bbox_to_anchor=(0.005, 0.78))
        ax.xaxis.set_major_locator(mdates.YearLocator(2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
        fig.autofmt_xdate(rotation=0, ha="center")
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, "stocks_overview_compact.png"),
                    dpi=200, bbox_inches="tight")
        plt.close(fig)


if __name__ == "__main__":
    print("plots.py is a library of plotting functions; import it from run.py.")
