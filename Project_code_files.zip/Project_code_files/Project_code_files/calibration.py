"""
calibration.py
==============
Multi-level calibration validation -- the primary scientific contribution.

For a model that produces a predictive distribution (BNN, MC-Dropout, the
PyMC Bayesian linear regression) we measure whether its stated credible
intervals actually contain the true value as often as they claim.

Definitions
-----------
For each nominal confidence level L we form a symmetric central interval
from the posterior predictive samples:

    L = 0.50  ->  25.0  to  75.0  percentile
    L = 0.70  ->  15.0  to  85.0  percentile
    L = 0.80  ->  10.0  to  90.0  percentile
    L = 0.90  ->   5.0  to  95.0  percentile
    L = 0.95  ->   2.5  to  97.5  percentile
    L = 0.99  ->   0.5  to  99.5  percentile

Observed coverage at level L for forecast step h is the fraction of test
days whose true value lies inside [lower, upper].

Expected Calibration Error (ECE) is the mean absolute gap between nominal
levels and observed coverage, averaged over all levels and all forecast
steps. ECE = 0 means perfect calibration.
"""

import numpy as np


LEVELS = [0.50, 0.70, 0.80, 0.90, 0.95, 0.99]


def _percentile_bounds(level):
    """Return the (low, high) percentile cuts for a symmetric central interval."""
    tail = (1.0 - level) / 2.0
    low = 100.0 * tail
    high = 100.0 * (1.0 - tail)
    return low, high


def compute_intervals(samples, levels=LEVELS):
    """Compute prediction intervals at each confidence level.

    Parameters
    ----------
    samples : (n_draws, n_test, n_out) posterior predictive draws.
    levels  : list of nominal confidence levels.

    Returns
    -------
    dict mapping each level to a tuple (lower, upper), each of shape
    (n_test, n_out).
    """
    intervals = {}
    for L in levels:
        lo_pct, hi_pct = _percentile_bounds(L)
        lower = np.percentile(samples, lo_pct, axis=0)
        upper = np.percentile(samples, hi_pct, axis=0)
        intervals[L] = (lower, upper)
    return intervals


def compute_coverage(y_true, intervals):
    """Observed coverage per level and per forecast step.

    Parameters
    ----------
    y_true    : (n_test, n_out) true values.
    intervals : dict mapping level -> (lower, upper).

    Returns
    -------
    dict mapping each level to an array of shape (n_out,) giving the observed
    coverage for each forecast step.
    """
    coverage = {}
    n_out = y_true.shape[1]
    for L, (lower, upper) in intervals.items():
        inside = (y_true >= lower) & (y_true <= upper)   # (n_test, n_out)
        coverage[L] = inside.mean(axis=0)                # (n_out,)
    return coverage


def compute_ece(coverage_dict, levels=LEVELS):
    """Mean absolute difference between nominal level and observed coverage.

    Averaged over all levels and all forecast steps.
    """
    diffs = []
    for L in levels:
        observed = coverage_dict[L]          # (n_out,)
        diffs.append(np.abs(L - observed))   # (n_out,)
    diffs = np.concatenate(diffs)
    return float(np.mean(diffs))


def calibration_summary(y_true, samples, model_name, levels=LEVELS):
    """Full calibration summary for one model.

    Returns a dict containing:
        model              : str
        levels             : list
        coverage_per_step  : {level: (n_out,) array}
        coverage_mean      : {level: float}   coverage averaged over steps
        ece                : float
        n_test             : int
    """
    intervals = compute_intervals(samples, levels)
    coverage = compute_coverage(y_true, intervals)
    ece = compute_ece(coverage, levels)

    coverage_mean = {L: float(np.mean(coverage[L])) for L in levels}
    coverage_per_step = {L: coverage[L].tolist() for L in levels}

    return {
        "model": model_name,
        "levels": list(levels),
        "coverage_per_step": coverage_per_step,
        "coverage_mean": coverage_mean,
        "ece": ece,
        "n_test": int(y_true.shape[0]),
    }


def compute_volatility_split_calibration(y_true, samples,
                                         low_vol_mask, high_vol_mask,
                                         model_name, levels=LEVELS):
    """Calibration computed separately on low- and high-volatility test days.

    Parameters
    ----------
    y_true       : (n_test, n_out)
    samples      : (n_draws, n_test, n_out)
    low_vol_mask : boolean array of length n_test
    high_vol_mask: boolean array of length n_test

    Returns
    -------
    dict with keys 'low_vol' and 'high_vol', each a full calibration summary.
    If a group is empty the corresponding value is None.
    """
    out = {}

    if low_vol_mask.sum() > 0:
        out["low_vol"] = calibration_summary(
            y_true[low_vol_mask],
            samples[:, low_vol_mask, :],
            model_name + " (low vol)",
            levels,
        )
    else:
        out["low_vol"] = None

    if high_vol_mask.sum() > 0:
        out["high_vol"] = calibration_summary(
            y_true[high_vol_mask],
            samples[:, high_vol_mask, :],
            model_name + " (high vol)",
            levels,
        )
    else:
        out["high_vol"] = None

    return out


# ============================================================================
# TEMPERATURE SCALING RECALIBRATION
# ============================================================================
# The raw BNN is overconfident: its intervals are too narrow, so the true
# value falls outside them more often than the stated confidence implies.
#
# Temperature scaling fixes this with ONE number, T. It widens (or narrows)
# the predictive distribution around its mean by the factor T:
#
#     recalibrated_sample = mean + T * (sample - mean)
#
# T > 1 widens the intervals (fixes overconfidence).
# T < 1 narrows them (fixes underconfidence).
# T = 1 leaves them unchanged.
#
# T is FITTED on a held-out calibration set (data the model did not train on),
# by searching for the T whose coverage best matches the nominal levels (lowest
# ECE). It is then APPLIED to the test set. The point predictions (the means)
# never move, so accuracy/RMSE is unchanged; only the interval widths change.
#
# This is the standard post-hoc recalibration approach (cf. Guo et al., 2017,
# "On Calibration of Modern Neural Networks"). It is honest because we report
# BOTH the before and after numbers.
# ============================================================================


def apply_temperature(samples, T):
    """Scale a predictive sample set around its per-point mean by factor T.

    samples : (n_draws, n_test, n_out)
    T       : float scaling factor
    returns : recalibrated samples of the same shape
    """
    mean = samples.mean(axis=0, keepdims=True)        # (1, n_test, n_out)
    return mean + T * (samples - mean)


def fit_temperature(y_calib, samples_calib, levels=LEVELS,
                    T_grid=None):
    """Find the temperature T that best calibrates a held-out set.

    Searches a grid of T values and returns the one giving the lowest ECE on
    the calibration data.

    Parameters
    ----------
    y_calib       : (n_calib, n_out) true values of the held-out calibration set
    samples_calib : (n_draws, n_calib, n_out) predictive draws for that set
    levels        : confidence levels to evaluate
    T_grid        : optional array of candidate T values; a sensible default
                    spanning 0.5 to 5.0 is used if None.

    Returns
    -------
    best_T   : float
    best_ece : float, the ECE achieved on the calibration set at best_T
    """
    if T_grid is None:
        # Fine near 1, coarser further out; overconfident models need T > 1.
        T_grid = np.concatenate([
            np.linspace(0.5, 1.0, 11)[:-1],
            np.linspace(1.0, 3.0, 41),
            np.linspace(3.0, 5.0, 11)[1:],
        ])

    best_T = 1.0
    best_ece = np.inf
    for T in T_grid:
        scaled = apply_temperature(samples_calib, T)
        intervals = compute_intervals(scaled, levels)
        coverage = compute_coverage(y_calib, intervals)
        ece = compute_ece(coverage, levels)
        if ece < best_ece:
            best_ece = ece
            best_T = float(T)
    return best_T, float(best_ece)


def recalibrate_summary(y_calib, samples_calib, y_test, samples_test,
                        model_name, levels=LEVELS):
    """Full before/after recalibration for one model.

    Fits T on the calibration set, applies it to the test set, and returns
    both the original and recalibrated calibration summaries plus T.

    Returns a dict:
        T            : fitted temperature
        before       : calibration_summary on the raw test samples
        after        : calibration_summary on the temperature-scaled test samples
        ece_before   : float
        ece_after    : float
    """
    T, _ = fit_temperature(y_calib, samples_calib, levels)

    before = calibration_summary(y_test, samples_test, model_name, levels)
    scaled_test = apply_temperature(samples_test, T)
    after = calibration_summary(
        y_test, scaled_test, model_name + " (recalibrated)", levels)

    return {
        "model": model_name,
        "T": T,
        "before": before,
        "after": after,
        "ece_before": before["ece"],
        "ece_after": after["ece"],
    }


if __name__ == "__main__":
    # Self-test: a well-calibrated Gaussian should give coverage near nominal.
    rng = np.random.RandomState(0)
    n_test, n_out, n_draws = 500, 5, 2000

    true_mean = rng.randn(n_test, n_out)
    true_sigma = 0.3
    y_true = true_mean + true_sigma * rng.randn(n_test, n_out)

    # Posterior predictive samples centred on the true mean with the right sigma.
    samples = (true_mean[None, :, :]
               + true_sigma * rng.randn(n_draws, n_test, n_out))

    summary = calibration_summary(y_true, samples, "TestGaussian")
    print("Well-calibrated Gaussian (coverage should track nominal):")
    for L in LEVELS:
        print(f"  nominal {L:.2f}  observed {summary['coverage_mean'][L]:.3f}")
    print(f"  ECE = {summary['ece']:.4f}  (should be small, < 0.05)")

    # --- Temperature scaling self-test ---
    # Build an OVERCONFIDENT model: predictive spread too small by 3x.
    print("\nTemperature scaling self-test:")
    overconf = (true_mean[None, :, :]
                + (true_sigma / 3.0) * rng.randn(n_draws, n_test, n_out))
    # Split into calibration and test halves.
    yc, yt = y_true[:250], y_true[250:]
    sc, st = overconf[:, :250, :], overconf[:, 250:, :]
    rec = recalibrate_summary(yc, sc, yt, st, "Overconfident")
    print(f"  fitted T = {rec['T']:.2f}  (should be ~3, to undo the 3x)")
    print(f"  ECE before = {rec['ece_before']:.4f}  (high, overconfident)")
    print(f"  ECE after  = {rec['ece_after']:.4f}  (should drop near 0)")
