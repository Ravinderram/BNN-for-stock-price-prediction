 """
run.py
======
Main orchestration script. This is the only file run directly.

It loops over the four stocks and the six experimental setups, trains all
five main models plus the PyMC reference, computes RMSE and multi-level
calibration, runs the three OHLCV analyses, saves all results to disk, and
produces every figure.

Usage
-----
    python run.py                # full run (slow: 100k MCMC samples x 10 chains)
    python run.py --quick        # fast smoke test (small MCMC budget)
    python run.py --stocks MMM   # restrict to one or more stocks
    python run.py --setups W1 W2 # restrict to one or more setups

Output goes to outputs/results, outputs/predictions, outputs/figures.
"""

import os
import sys
import json
import argparse
import warnings
import multiprocessing as mp

# Quieten noisy third-party startup messages BEFORE importing them.
# These are harmless (g++ missing only affects PyMC speed; oneDNN is a
# TensorFlow CPU notice). Suppressing them keeps the progress bar readable.
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")
os.environ.setdefault("PYTENSOR_FLAGS", "cxx=")   # silences the g++ warning

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import data
import bnn
import baselines
import calibration
import plots

try:
    import pymc_reference
    _HAS_PYMC = True
except Exception:
    _HAS_PYMC = False


# ----------------------------------------------------------------------------
# Output directories
# ----------------------------------------------------------------------------
RESULTS_DIR = os.path.join("outputs", "results")
PRED_DIR = os.path.join("outputs", "predictions")
FIG_DIR = os.path.join("outputs", "figures")


def _make_dirs():
    for d in (RESULTS_DIR, PRED_DIR, FIG_DIR):
        os.makedirs(d, exist_ok=True)


# ----------------------------------------------------------------------------
# Full BNN configuration (paper-faithful values)
# ----------------------------------------------------------------------------
BNN_CONFIG = {
    "n_samples": 100000,           # total MCMC steps per chain
                                  # (paper uses 100000; 30000 gives nearly
                                  #  identical calibration much faster. Raise
                                  #  to 100000 for the final paper-faithful run.)
    "n_chains": 10,                # number of parallel chains
                                  # (paper uses 10; 6 samples this small
                                  #  network well with less overhead.)
    "max_temp": 1.5,              # INITIAL hottest-chain temperature (was
                                  #  2.0). With the adaptive ladder below
                                  #  this is only the starting point; the
                                  #  ladder retunes itself during burn-in.
                                  #  Narrower initial gaps also help on
                                  #  their own (Task 6, fix #2): swap
                                  #  acceptance depends on the product of
                                  #  the gap (1/Ta - 1/Tb) and the
                                  #  log-likelihood difference, which
                                  #  scales with training-set size N.
    "swap_interval": 5,           # steps between swap attempts
    # --- adaptive temperature ladder (Task 6, best fix) ---
    # Per-pair Robbins-Monro tuning of the ladder gaps during burn-in
    # toward a ~23.4% per-pair swap acceptance (Vousden, Farr & Mandel
    # 2016; same idea as emcee's PTSampler). No single fixed ladder is
    # right for all 24 stock/setup combos because N (and hence the
    # log-likelihood fluctuation scale) differs across them. The ladder
    # FREEZES at the end of burn-in; the reported health metric
    # swap_rate_post_burnin measures the frozen ladder. Disable with
    # --fixed-ladder for a before/after comparison.
    "adaptive_ladder": True,
    "swap_target": 0.234,         # per-pair target acceptance
    "ladder_kappa0": 0.6,         # initial adaptation gain
    "ladder_t0": 100.0,           # gain decay timescale (in swap rounds)
    "ladder_adapt_delay": 25,     # rounds before adaptation begins (lets
                                  #  chains equilibrate to their
                                  #  temperatures first)
    "ladder_max_gap": 20.0,       # cap on any single temperature gap
    "burn_in": 0.50,              # fraction of samples discarded
    # --- proposal step sizes (initial; adapted during burn-in) ---
    # The extended dataset has ~8760 scalar outputs feeding a single shared
    # tau, so the Gaussian log-likelihood is razor-sharp in the 60-D weight
    # space. The old defaults (step_w=0.005, lg_rate=0.01) proposed jumps far
    # too large for that geometry: RW accepted ~1-3% and Langevin ~0%. These
    # smaller starting points sit in the right basin and let the adapter find
    # the healthy range quickly.
    "step_w": 0.001,              # initial RW step size for weights
    "step_tau": 0.05,             # initial RW step size for log tau
    "sigma_w_sq": 25.0,           # weight prior variance
    # --- tau (noise variance) prior: Inverse-Gamma(gamma_a, gamma_b) ---
    # Loosened from gamma_a=2.0 (prior mean = gamma_b/(gamma_a-1) = 0.05),
    # which biased tau_sq toward small values, i.e. toward overconfident
    # intervals, before the data said anything. gamma_a=1.1 keeps the same
    # mode region but gives the prior a much heavier right tail (mean 0.5),
    # so tau_sq can grow when crisis-period residuals demand it. NOTE: the
    # prior is deliberately NOT set from test-period variance - that would
    # leak crisis information into the model.
    "gamma_a": 1.1,               # tau prior shape parameter (was 2.0)
    "gamma_b": 0.05,              # tau prior rate parameter
    # --- heteroskedastic noise (BNN improvement, root-cause fix) ---
    # tau_i^2 = exp(log_tau_sq + gamma_v * vol_i), where vol_i is the
    # standardised std of window i's inputs (train-standardised, no
    # leakage). gamma_v is sampled in its own Metropolis block; gamma_v = 0
    # recovers the original homoskedastic model exactly (nested). Same
    # covariate and mechanism as the Bayes-LR heteroskedastic fix, so the
    # story is consistent across models. Disable with --bnn-homoskedastic
    # for a before/after comparison.
    "heteroskedastic": True,
    "step_gv": 0.05,              # initial RW step size for gamma_v
    "gv_target": 0.44,            # target acceptance (optimal scalar RW)
    "adapt_interval": 200,        # steps between adaptation (was 500; tighter
                                  #  windows converge step sizes within burn-in)
    # Separate acceptance targets: random-walk Metropolis and MALA have
    # different optimal rates in high dimension (~0.234 and ~0.574). A single
    # 0.40 target was wrong for both.
    "rw_target": 0.30,            # target acceptance for random-walk moves
    "lg_target": 0.55,            # target acceptance for Langevin moves
    "target_accept": 0.40,        # (legacy; kept for backward compatibility)
    "lg_prob": 0.50,              # probability of Langevin proposal
    "lg_rate": 1e-5,              # Langevin step size r (MALA noise std is
                                  #  sqrt(lg_rate)); paper's 0.1 is ~30x too
                                  #  large for this sharp posterior.
    # Adaptation bounds (Robbins-Monro log-scale updates clip to these).
    "step_w_min": 1e-5, "step_w_max": 0.1,
    "step_tau_min": 1e-3, "step_tau_max": 0.5,
    "lg_rate_min": 1e-9, "lg_rate_max": 1e-2,
    "debug_accept": False,        # set True to print the RW/LG accept split
                                  #  at every adaptation checkpoint (cold chain)
    "lg_grad_clip": 5.0,          # maximum gradient norm
    "warmup_steps": 200,          # gradient ascent warm-up steps
    "max_posterior_samples": 5000,
    "topology": (5, 5, 5),
}

# Reduced settings used by --quick.
QUICK_OVERRIDES = {
    "n_samples": 4000,
    "n_chains": 4,
    "warmup_steps": 200,
    "max_posterior_samples": 500,
}

TOPOLOGY = (5, 5, 5)


# ----------------------------------------------------------------------------
# Per stock/setup runner
# ----------------------------------------------------------------------------
def run_one(stock_name, df_full, setup_name, setup_cfg, bnn_config,
            pymc_settings):
    """Run all models for one stock and one setup. Returns a result bundle."""
    print(f"\n=== {stock_name} / {setup_name} "
          f"({setup_cfg['label']}) ===")

    Xtr, ytr, Xte, yte, test_dates, scaler = data.normalise_and_split(
        df_full, setup_cfg["train_end"],
        setup_cfg["test_start"], setup_cfg["test_end"])

    print(f"  train {Xtr.shape}, test {Xte.shape}")
    if Xte.shape[0] < 5:
        print("  Test set too small; skipping.")
        return None

    # ---- baselines ----
    print("  Training baselines (FNN-Adam, FNN-SGD, LSTM, MC-Dropout)...")
    n_passes = 500 if not pymc_settings["quick"] else 100
    base = baselines.train_all_baselines(Xtr, ytr, Xte, yte, n_passes=n_passes)

    # ---- BNN ----
    print("  Running LG-PT-MCMC BNN...")
    bnn_res = bnn.run_bnn(Xtr, ytr, Xte, yte, TOPOLOGY, bnn_config)
    print(f"    BNN RMSE={bnn_res['rmse_overall']:.4f}  "
          f"accept={bnn_res['accept_rate']:.3f}  "
          f"swap={bnn_res['swap_rate']:.3f}  "
          f"swap_post_burnin={bnn_res['swap_rate_post_burnin']:.3f}")
    if bnn_res.get("heteroskedastic"):
        print(f"    BNN heteroskedastic: gamma_v mean = "
              f"{bnn_res['gamma_v_mean']:.3f} "
              f"(0 = homoskedastic; positive = noise widens with "
              f"volatility)")

    # ---- PyMC reference ----
    bayes_lr_res = None
    if _HAS_PYMC and pymc_settings["use_pymc"]:
        print("  Fitting PyMC Bayesian linear regression reference...")
        try:
            bayes_lr_res = pymc_reference.fit_bayes_lr(
                Xtr, ytr, Xte, yte,
                draws=pymc_settings["draws"],
                tune=pymc_settings["tune"],
                chains=pymc_settings["chains"],
                cores=4,
            )
            _rps = bayes_lr_res["rmse_per_step"]
            print(f"    Bayes-LR RMSE (all {len(_rps)} steps)"
                  f"={bayes_lr_res['rmse_overall']:.4f}  "
                  f"per-step={[round(v, 4) for v in _rps]}")
        except Exception as e:
            print(f"    PyMC reference failed: {e}")
            bayes_lr_res = None

    # ---- assemble all models ----
    all_models = {"BNN": bnn_res}
    all_models.update(base)
    if bayes_lr_res is not None:
        all_models["Bayes-LR"] = bayes_lr_res

    # ---- calibration summaries (interval models only) ----
    calib = {}
    calib["BNN"] = calibration.calibration_summary(
        yte, bnn_res["samples"], "BNN")
    calib["MC-Dropout"] = calibration.calibration_summary(
        yte, base["MC-Dropout"]["samples"], "MC-Dropout")
    if bayes_lr_res is not None:
        # Bayes-LR now models every horizon, so its calibration is evaluated
        # on the same targets as BNN and MC-Dropout. Previously this was
        # scored on step 1 only, which made the ECE comparison unequal:
        # step 1 is the easiest horizon, so Bayes-LR was being graded on a
        # strictly easier task than the models it was being compared against.
        _n = bayes_lr_res["samples"].shape[2]
        calib["Bayes-LR"] = calibration.calibration_summary(
            yte[:, :_n], bayes_lr_res["samples"], "Bayes-LR")

    # ---- temperature-scaling recalibration (the honest "we fixed it" step) ----
    # Fit the temperature T on the FIRST half of the test window (held-out
    # calibration data the model never trained on), then apply it to the
    # SECOND half and measure before vs after. This shows whether the
    # overconfidence can be corrected with a simple one-parameter fix.
    recalib = {}
    n_te = yte.shape[0]
    if n_te >= 20:  # need enough points to split meaningfully
        half = n_te // 2
        # BNN
        recalib["BNN"] = calibration.recalibrate_summary(
            yte[:half], bnn_res["samples"][:, :half, :],
            yte[half:], bnn_res["samples"][:, half:, :], "BNN")
        # MC-Dropout
        mc_s = base["MC-Dropout"]["samples"]
        recalib["MC-Dropout"] = calibration.recalibrate_summary(
            yte[:half], mc_s[:, :half, :],
            yte[half:], mc_s[:, half:, :], "MC-Dropout")
        print(f"    Temperature scaling: "
              f"BNN T={recalib['BNN']['T']:.2f} "
              f"ECE {recalib['BNN']['ece_before']:.3f} -> "
              f"{recalib['BNN']['ece_after']:.3f}")

    # ---- volatility-stratified calibration ----
    high_series = df_full.set_index("Date")["High"]
    low_series = df_full.set_index("Date")["Low"]
    close_series = df_full.set_index("Date")["Close"]
    low_mask, high_mask, vol_thresh = data.get_volatility_split(
        test_dates, high_series, low_series, close_series)

    split_calib = {}
    split_calib["BNN"] = calibration.compute_volatility_split_calibration(
        yte, bnn_res["samples"], low_mask, high_mask, "BNN")
    split_calib["MC-Dropout"] = calibration.compute_volatility_split_calibration(
        yte, base["MC-Dropout"]["samples"], low_mask, high_mask, "MC-Dropout")

    # ---- volume spikes ----
    vol_ratio = data.compute_volume_ratio(df_full)
    vol_ratio.index = df_full["Date"]
    spikes = data.compute_volume_spikes(vol_ratio, test_dates, top_n=10)

    # BNN step-1 error aligned with test dates.
    bnn_step1_err = np.abs(yte[:, 0] - bnn_res["pred"][:, 0])
    bnn_iw95 = (bnn_res["fx_high_95"][:, 0] - bnn_res["fx_low_95"][:, 0])

    # Map spike dates to indices in test_dates for error/width columns.
    test_dates_idx = {pd.Timestamp(d): i for i, d in enumerate(test_dates)}
    spike_rows = []
    closes = df_full.set_index("Date")["Close"]
    for _, row in spikes.iterrows():
        d = pd.Timestamp(row["date"])
        i = test_dates_idx.get(d, None)
        if i is None:
            continue
        # daily return at d
        try:
            pos = closes.index.get_loc(d)
            if pos > 0:
                daily_ret = (closes.iloc[pos] / closes.iloc[pos - 1]) - 1.0
            else:
                daily_ret = np.nan
        except Exception:
            daily_ret = np.nan
        spike_rows.append({
            "date": d.strftime("%Y-%m-%d"),
            "vol_ratio": float(row["vol_ratio"]),
            "daily_return_pct": float(daily_ret * 100.0)
            if np.isfinite(daily_ret) else np.nan,
            "bnn_step1_error": float(bnn_step1_err[i]),
            "bnn_interval_width_95": float(bnn_iw95[i]),
        })
    spikes_df = pd.DataFrame(spike_rows)

    return {
        "stock": stock_name,
        "setup": setup_name,
        "test_dates": test_dates,
        "y_test": yte,
        "all_models": all_models,
        "calibration": calib,
        "recalibration": recalib,
        "split_calibration": split_calib,
        "vol_ratio": vol_ratio,
        "spikes_df": spikes_df,
        "spike_dates": [pd.Timestamp(r["date"]) for r in spike_rows],
        "bnn_step1_err": bnn_step1_err,
        "vol_threshold": vol_thresh,
    }


# ----------------------------------------------------------------------------
# Persistence
# ----------------------------------------------------------------------------
def save_results_json(bundle):
    """Save a per-stock-per-setup JSON of metrics and calibration."""
    stock = bundle["stock"]
    setup = bundle["setup"]

    out = {"stock": stock, "setup": setup, "models": {}}
    for m, res in bundle["all_models"].items():
        entry = {
            "rmse_overall": res["rmse_overall"],
            "rmse_per_step": res["rmse_per_step"],
        }
        if m == "BNN":
            entry["accept_rate"] = res.get("accept_rate")
            entry["swap_rate"] = res.get("swap_rate")
            entry["swap_rate_post_burnin"] = res.get("swap_rate_post_burnin")
            entry["swap_rate_per_pair"] = res.get("swap_rate_per_pair")
            entry["adaptive_ladder"] = res.get("adaptive_ladder")
            entry["final_temperatures"] = res.get("final_temperatures")
            entry["heteroskedastic"] = res.get("heteroskedastic")
            entry["gamma_v_mean"] = res.get("gamma_v_mean")
            entry["ess_pred"] = res.get("ess_pred")
            entry["ess_tau"] = res.get("ess_tau")
        out["models"][m] = entry

    out["calibration"] = {}
    for m, summary in bundle["calibration"].items():
        out["calibration"][m] = {
            "ece": summary["ece"],
            "coverage_mean": summary["coverage_mean"],
        }

    out["volatility_split"] = {}
    for m, groups in bundle["split_calibration"].items():
        out["volatility_split"][m] = {}
        for grp_name, summary in groups.items():
            if summary is None:
                out["volatility_split"][m][grp_name] = None
            else:
                out["volatility_split"][m][grp_name] = {
                    "ece": summary["ece"],
                    "coverage_95": summary["coverage_mean"].get(0.95),
                }

    # Temperature-scaling recalibration results.
    out["recalibration"] = {}
    for m, rec in bundle.get("recalibration", {}).items():
        if rec is None:
            continue
        out["recalibration"][m] = {
            "T": rec["T"],
            "ece_before": rec["ece_before"],
            "ece_after": rec["ece_after"],
            "coverage_mean_before": rec["before"]["coverage_mean"],
            "coverage_mean_after": rec["after"]["coverage_mean"],
        }

    path = os.path.join(RESULTS_DIR, f"{stock}_{setup}_results.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)


def save_predictions_csv(bundle):
    """Save actual + predicted prices per model for this stock/setup."""
    stock = bundle["stock"]
    setup = bundle["setup"]
    dates = pd.to_datetime(list(bundle["test_dates"]))
    yte = bundle["y_test"]

    df = pd.DataFrame({"date": dates})
    for h in range(5):
        df[f"actual_step{h+1}"] = yte[:, h]

    for m, res in bundle["all_models"].items():
        pred = res["pred"]
        n_out = pred.shape[1]
        for h in range(n_out):
            df[f"{m}_step{h+1}"] = pred[:, h]
        if "fx_low_95" in res:
            lo = res["fx_low_95"]
            hi = res["fx_high_95"]
            for h in range(lo.shape[1]):
                df[f"{m}_low95_step{h+1}"] = lo[:, h]
                df[f"{m}_high95_step{h+1}"] = hi[:, h]

    path = os.path.join(PRED_DIR, f"{stock}_{setup}_predictions.csv")
    df.to_csv(path, index=False)


def save_volume_spikes_csv(bundle):
    stock = bundle["stock"]
    setup = bundle["setup"]
    if len(bundle["spikes_df"]) > 0:
        path = os.path.join(RESULTS_DIR,
                            f"volume_spikes_{stock}_{setup}.csv")
        bundle["spikes_df"].to_csv(path, index=False)


# ----------------------------------------------------------------------------
# Plotting for one bundle
# ----------------------------------------------------------------------------
def make_setup_plots(bundle):
    stock = bundle["stock"]
    setup = bundle["setup"]

    plots.plot_forecast_with_intervals(
        bundle["test_dates"], bundle["y_test"],
        bundle["all_models"]["BNN"], bundle["all_models"]["MC-Dropout"],
        stock, setup, FIG_DIR)

    plots.plot_rmse_comparison(bundle["all_models"], stock, setup, FIG_DIR)

    plots.plot_calibration_curves(bundle["calibration"], stock, setup, FIG_DIR)

    # Temperature-scaling before/after figure.
    if bundle.get("recalibration"):
        plots.plot_recalibration(
            bundle["recalibration"], stock, setup, FIG_DIR)

    plots.plot_calibration_volatility_split(
        bundle["split_calibration"], stock, setup, FIG_DIR)

    plots.plot_volume_spikes(
        bundle["vol_ratio"], bundle["test_dates"], bundle["spike_dates"],
        bundle["bnn_step1_err"], stock, setup, FIG_DIR)

    # Presentation-focused per-setup plots.
    plots.plot_fan_chart(
        bundle["test_dates"], bundle["y_test"],
        bundle["all_models"]["BNN"]["samples"], stock, setup, FIG_DIR)

    plots.plot_mcmc_trace(
        bundle["all_models"]["BNN"], stock, setup, FIG_DIR)

    # All forecast horizons, not just step 1. The models predict 5 days
    # ahead, so every horizon gets its own panel; this shows error and
    # interval width growing with forecast distance.
    for _mname in ("Bayes-LR", "BNN", "MC-Dropout"):
        _res = bundle["all_models"].get(_mname)
        if _res is None or "fx_low_95" not in _res:
            continue
        _H = np.asarray(_res["pred"]).shape[1]
        if _H < 2:
            continue          # nothing multi-step to show
        plots.plot_multistep_forecast(
            bundle["test_dates"], bundle["y_test"], _res, _mname,
            stock, setup, FIG_DIR)
        if "samples" in _res:
            plots.plot_multistep_fan_chart(
                bundle["test_dates"], bundle["y_test"], _res["samples"],
                _mname, stock, setup, FIG_DIR)

    # Task 1: BNN vs MC-Dropout vs Bayes-LR sample sequences on one figure.
    # The per-model "samples" arrays are still in memory inside the bundle at
    # this point (run.py passes the full result dicts through, not just
    # summary stats), so no extra sampling is needed - just slice the
    # predicted value at the first test point, first forecast step.
    am = bundle["all_models"]
    bnn_trace = am["BNN"]["samples"][:, 0, 0]
    mc_trace = am["MC-Dropout"]["samples"][:, 0, 0]
    lr_trace = (am["Bayes-LR"]["samples"][:, 0, 0]
                if "Bayes-LR" in am else None)
    plots.plot_combined_model_traces(
        bnn_trace, mc_trace, lr_trace, stock, setup, FIG_DIR)

    # Task 2: burn-in stabilisation diagnostic (BNN cold chain, full trace).
    plots.plot_burnin_diagnostic(
        am["BNN"].get("burnin_diag"), stock, setup, FIG_DIR)


def save_traces_npz(bundle):
    """Persist the raw trace arrays as binary (.npz), not text JSON.

    Binary keeps the files small and is fine for data only consumed by
    plotting code; text JSON would inflate size 2-3x for no benefit.
    """
    stock = bundle["stock"]
    setup = bundle["setup"]
    am = bundle["all_models"]
    arrays = {
        "bnn_trace": am["BNN"]["samples"][:, 0, 0],
        "mcdropout_trace": am["MC-Dropout"]["samples"][:, 0, 0],
    }
    if "Bayes-LR" in am:
        arrays["bayeslr_trace"] = am["Bayes-LR"]["samples"][:, 0, 0]
    diag = am["BNN"].get("burnin_diag")
    if diag:
        arrays["burnin_trace"] = np.asarray(diag["trace"])
        arrays["burnin_indices"] = np.asarray(diag["indices"])
        arrays["burn_index"] = np.array(diag["burn_index"])
        arrays["n_total"] = np.array(diag["n_total"])
    path = os.path.join(RESULTS_DIR, f"traces_{stock}_{setup}.npz")
    np.savez_compressed(path, **arrays)


# ----------------------------------------------------------------------------
# Summary tables
# ----------------------------------------------------------------------------
def build_summary(all_bundles):
    """Build the cross-setup summary DataFrame and ECE tables."""
    rows = []
    split_rows = []

    for bundle in all_bundles:
        stock = bundle["stock"]
        setup = bundle["setup"]
        calib = bundle["calibration"]
        split = bundle["split_calibration"]

        for m, res in bundle["all_models"].items():
            row = {"stock": stock, "setup": setup, "model": m}
            rps = res["rmse_per_step"]
            for h in range(5):
                row[f"rmse_step{h+1}"] = rps[h] if h < len(rps) else np.nan
            row["rmse_overall"] = res["rmse_overall"]

            # calibration columns (only interval models)
            if m in calib:
                summary = calib[m]
                row["ece"] = summary["ece"]
                for L in calibration.LEVELS:
                    pct = int(L * 100)
                    row[f"coverage_{pct}"] = summary["coverage_mean"][L]
            else:
                row["ece"] = np.nan
                for L in calibration.LEVELS:
                    row[f"coverage_{int(L*100)}"] = np.nan

            # mcmc acceptance
            row["mcmc_acceptance_rate"] = (
                res.get("accept_rate") if m == "BNN" else np.nan)

            # volatility split columns
            if m in split:
                lo = split[m].get("low_vol")
                hi = split[m].get("high_vol")
                row["ece_low_vol"] = lo["ece"] if lo else np.nan
                row["ece_high_vol"] = hi["ece"] if hi else np.nan
                row["coverage_95_low_vol"] = (
                    lo["coverage_mean"].get(0.95) if lo else np.nan)
                row["coverage_95_high_vol"] = (
                    hi["coverage_mean"].get(0.95) if hi else np.nan)
            else:
                row["ece_low_vol"] = np.nan
                row["ece_high_vol"] = np.nan
                row["coverage_95_low_vol"] = np.nan
                row["coverage_95_high_vol"] = np.nan

            rows.append(row)

            # volatility split detail table (interval models only)
            if m in split:
                lo = split[m].get("low_vol")
                hi = split[m].get("high_vol")
                split_rows.append({
                    "stock": stock, "setup": setup, "model": m,
                    "ece_low_vol": lo["ece"] if lo else np.nan,
                    "ece_high_vol": hi["ece"] if hi else np.nan,
                    "ece_overall": calib[m]["ece"] if m in calib else np.nan,
                    "vol_threshold_used": bundle["vol_threshold"],
                })

    summary_df = pd.DataFrame(rows)
    split_df = pd.DataFrame(split_rows)
    return summary_df, split_df


def build_intraday_summary(stocks):
    frames = []
    for name, df in stocks.items():
        frames.append(data.monthly_intraday_summary(df, name))
    return pd.concat(frames, ignore_index=True)


# ----------------------------------------------------------------------------
# Loading ALL results from disk (so summary plots accumulate across runs)
# ----------------------------------------------------------------------------
def load_all_results_from_disk():
    """Read every {stock}_{setup}_results.json saved in RESULTS_DIR.

    This lets the cross-stock / cross-setup summary figures include results
    from previous runs, not just the current command. So you can run one
    stock at a time and still get complete combined plots at the end.

    Returns
    -------
    summary_rows   : list of dicts, one per (stock, setup, model).
    calib_by_setup : dict setup -> list of calibration dicts (one per stock).
    grid_by_setup  : dict setup -> {stock -> calibration dict}.
    split_rows     : list of dicts for the volatility-split ECE table.
    """
    import glob

    summary_rows = []
    split_rows = []
    calib_by_setup = {}
    grid_by_setup = {}

    pattern = os.path.join(RESULTS_DIR, "*_results.json")
    for path in sorted(glob.glob(pattern)):
        try:
            with open(path) as f:
                d = json.load(f)
        except Exception:
            continue

        stock = d.get("stock")
        setup = d.get("setup")
        if stock is None or setup is None:
            continue

        calib = d.get("calibration", {})
        vol_split = d.get("volatility_split", {})

        # Rebuild calibration summaries in the structure the plots expect.
        # JSON stores coverage_mean keys as strings, so convert back to float.
        calib_reconstructed = {}
        for model_name, c in calib.items():
            cov_mean = {float(k): v for k, v in c["coverage_mean"].items()}
            calib_reconstructed[model_name] = {
                "model": model_name,
                "levels": sorted(cov_mean.keys()),
                "coverage_mean": cov_mean,
                "ece": c["ece"],
            }
        calib_by_setup.setdefault(setup, []).append(calib_reconstructed)
        grid_by_setup.setdefault(setup, {})[stock] = calib_reconstructed

        # Summary rows for every model.
        for model_name, m in d.get("models", {}).items():
            row = {"stock": stock, "setup": setup, "model": model_name}
            rps = m.get("rmse_per_step", [])
            for h in range(5):
                row[f"rmse_step{h+1}"] = rps[h] if h < len(rps) else np.nan
            row["rmse_overall"] = m.get("rmse_overall", np.nan)

            if model_name in calib_reconstructed:
                summary = calib_reconstructed[model_name]
                row["ece"] = summary["ece"]
                for L in calibration.LEVELS:
                    row[f"coverage_{int(L*100)}"] = \
                        summary["coverage_mean"].get(L, np.nan)
            else:
                row["ece"] = np.nan
                for L in calibration.LEVELS:
                    row[f"coverage_{int(L*100)}"] = np.nan

            row["mcmc_acceptance_rate"] = m.get("accept_rate", np.nan)

            vs = vol_split.get(model_name, {})
            lo = vs.get("low_vol") if isinstance(vs, dict) else None
            hi = vs.get("high_vol") if isinstance(vs, dict) else None
            row["ece_low_vol"] = lo["ece"] if lo else np.nan
            row["ece_high_vol"] = hi["ece"] if hi else np.nan
            row["coverage_95_low_vol"] = lo.get("coverage_95") if lo else np.nan
            row["coverage_95_high_vol"] = hi.get("coverage_95") if hi else np.nan
            summary_rows.append(row)

            if lo is not None or hi is not None:
                split_rows.append({
                    "stock": stock, "setup": setup, "model": model_name,
                    "ece_low_vol": lo["ece"] if lo else np.nan,
                    "ece_high_vol": hi["ece"] if hi else np.nan,
                    "ece_overall": (calib_reconstructed[model_name]["ece"]
                                    if model_name in calib_reconstructed
                                    else np.nan),
                    "vol_threshold_used": np.nan,
                })

    return summary_rows, calib_by_setup, grid_by_setup, split_rows


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true",
                        help="fast smoke test with reduced MCMC budget")
    parser.add_argument("--stocks", nargs="*", default=None,
                        help="subset of stock keys, e.g. MMM CBA_AX")
    parser.add_argument("--setups", nargs="*", default=None,
                        help="subset of setup keys, e.g. W1 W2")
    parser.add_argument("--no-pymc", action="store_true",
                        help="skip the PyMC reference model")
    parser.add_argument("--bnn-homoskedastic", action="store_true",
                        help="disable the heteroskedastic BNN noise model "
                             "(revert to the original single global tau_sq, "
                             "for before/after comparison)")
    parser.add_argument("--fixed-ladder", action="store_true",
                        help="disable the adaptive parallel-tempering "
                             "temperature ladder (revert to the fixed "
                             "geometric ladder, for before/after "
                             "comparison)")
    parser.add_argument("--data-dir", default=".",
                        help="directory containing the CSV files")
    args = parser.parse_args()

    _make_dirs()

    # Build BNN config.
    bnn_config = dict(BNN_CONFIG)
    if args.quick:
        bnn_config.update(QUICK_OVERRIDES)
        print("QUICK MODE: reduced MCMC budget.")
    if args.bnn_homoskedastic:
        bnn_config["heteroskedastic"] = False
        print("BNN: heteroskedastic noise DISABLED (original model).")
    if args.fixed_ladder:
        bnn_config["adaptive_ladder"] = False
        print("BNN: adaptive PT ladder DISABLED (fixed geometric ladder).")

    pymc_settings = {
        "use_pymc": (not args.no_pymc) and _HAS_PYMC,
        "quick": args.quick,
        "draws": 500 if args.quick else 2000,
        "tune": 500 if args.quick else 1000,
        "chains": 2 if args.quick else 4,
    }

    # Load data.
    stocks = data.load_all_stocks(args.data_dir)
    splits = data.get_experiment_splits()

    stock_keys = args.stocks if args.stocks else list(stocks.keys())
    setup_keys = args.setups if args.setups else list(splits.keys())

    # Per-stock global figures (volatility intraday) and intraday summary CSV.
    for sk in stock_keys:
        plots.plot_volatility_intraday(stocks[sk], sk, FIG_DIR)

    # Task 5: compact multi-stock overview for the presentation. Crisis
    # shading uses the EXACT test-window boundaries from
    # data.get_experiment_splits() (R2/W2/M2 are subsets of R1/W1/M1), not
    # approximate public crisis dates. Always uses all four stocks so the
    # figure is complete even when --stocks restricts the model runs.
    crisis_windows = [
        (splits["R1"]["test_start"], splits["R1"]["test_end"],
         "COVID-19\n(R1/R2)"),
        (splits["W1"]["test_start"], splits["W1"]["test_end"],
         "Russia-\nUkraine\n(W1/W2)"),
        (splits["M1"]["test_start"], splits["M1"]["test_end"],
         "Middle East\nconflict\n(M1/M2)"),
    ]
    plots.plot_stocks_overview_compact(stocks, crisis_windows, FIG_DIR)
    intraday_summary = build_intraday_summary(
        {k: stocks[k] for k in stock_keys})
    intraday_summary.to_csv(
        os.path.join(RESULTS_DIR, "intraday_range_summary.csv"), index=False)

    # Main loop.
    all_bundles = []
    for sk in stock_keys:
        for setup in setup_keys:
            bundle = run_one(sk, stocks[sk], setup, splits[setup],
                             bnn_config, pymc_settings)
            if bundle is None:
                continue
            save_results_json(bundle)
            save_predictions_csv(bundle)
            save_volume_spikes_csv(bundle)
            save_traces_npz(bundle)
            make_setup_plots(bundle)
            all_bundles.append(bundle)

    if not all_bundles:
        print("No results produced.")
        return

    # ------------------------------------------------------------------
    # Summary tables and cross-stock/cross-setup figures.
    #
    # IMPORTANT: these are built from ALL results saved on disk (every
    # {stock}_{setup}_results.json in outputs/results), not just the stocks
    # and setups in the current command. This means you can run one stock at
    # a time across separate commands, and the combined summary figures will
    # still include every stock whose results exist on disk.
    # ------------------------------------------------------------------
    summary_rows, calib_by_setup, grid_by_setup, split_rows = \
        load_all_results_from_disk()

    summary_df = pd.DataFrame(summary_rows)
    split_df = pd.DataFrame(split_rows)

    summary_df.to_csv(os.path.join(RESULTS_DIR, "summary.csv"), index=False)
    if not split_df.empty:
        split_df.to_csv(os.path.join(RESULTS_DIR, "volatility_split_ece.csv"),
                        index=False)

    # ECE summary table (just the calibration ECE per model/stock/setup).
    if not summary_df.empty:
        ece_cols = summary_df[summary_df["ece"].notna()][
            ["stock", "setup", "model", "ece"]]
        ece_cols.to_csv(os.path.join(RESULTS_DIR, "ece_summary.csv"),
                        index=False)

    # Combined calibration curves, one per setup, averaged over all stocks
    # found on disk.
    for setup, calib_list in calib_by_setup.items():
        plots.plot_calibration_combined(calib_list, setup, FIG_DIR)

    # ECE heatmap: rows = model, cols = stock_setup.
    if not summary_df.empty:
        pivot = summary_df.copy()
        pivot["col"] = pivot["stock"] + "_" + pivot["setup"]
        ece_table = pivot.pivot_table(index="model", columns="col",
                                      values="ece")
        if not ece_table.empty:
            plots.plot_ece_heatmap(ece_table, FIG_DIR)

    # ECE volatility split chart.
    if not split_df.empty:
        plots.plot_ece_volatility_split(split_df, FIG_DIR)

    # Setup comparison RMSE chart.
    if not summary_df.empty:
        plots.plot_setup_comparison_rmse(summary_df, FIG_DIR)

    # ----- Presentation-focused summary figures -----
    # Conceptual teaching plots (no data needed).
    plots.plot_concept_point_vs_distribution(FIG_DIR)
    plots.plot_concept_calibration_explained(FIG_DIR)

    # Headline result plots built from the (full, on-disk) summary table.
    if not summary_df.empty:
        plots.plot_ece_ranking(summary_df, FIG_DIR)
        plots.plot_accuracy_vs_calibration(summary_df, FIG_DIR)
        plots.plot_crisis_coverage_comparison(summary_df, FIG_DIR)
        # Task 4: same question, but for all three interval models.
        plots.plot_coverage_comparison_all_models(summary_df, FIG_DIR)
        plots.plot_summary_dashboard(summary_df, FIG_DIR)

    # Multi-stock calibration grid, one per setup, from all stocks on disk.
    for setup, grid in grid_by_setup.items():
        plots.plot_calibration_grid(grid, setup, FIG_DIR)

    # ----- Temperature-scaling recalibration summary (from all on-disk runs) -
    import glob
    recalib_rows = []
    for path in sorted(glob.glob(os.path.join(RESULTS_DIR, "*_results.json"))):
        try:
            with open(path) as f:
                d = json.load(f)
        except Exception:
            continue
        rc = d.get("recalibration", {})
        for m, r in rc.items():
            recalib_rows.append({
                "stock": d.get("stock"), "setup": d.get("setup"),
                "model": m,
                "ece_before": r.get("ece_before"),
                "ece_after": r.get("ece_after"),
                "T": r.get("T"),
            })
    if recalib_rows:
        plots.plot_recalibration_summary(recalib_rows, FIG_DIR)
        # Also save a small CSV of the recalibration results.
        pd.DataFrame(recalib_rows).to_csv(
            os.path.join(RESULTS_DIR, "recalibration_summary.csv"), index=False)

    print("\nDone. Results in outputs/.")
    print("(Summary figures include ALL results saved in outputs/results, "
          "not just this run.)")
    if not summary_df.empty:
        print(summary_df[["stock", "setup", "model", "rmse_overall", "ece"]]
              .to_string(index=False))


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    main()
