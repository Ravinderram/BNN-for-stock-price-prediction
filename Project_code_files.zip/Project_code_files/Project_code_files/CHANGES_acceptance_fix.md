# Acceptance-rate fix

## Problem
Cold-chain weight acceptance was ~0.004–0.012 despite 100k samples / 10 chains.

## Root cause
The extended dataset has ~8760 scalar outputs feeding one shared tau, so the
Gaussian log-likelihood is razor-sharp in 60-D weight space. The old proposal
steps were far too large for that geometry:
- Langevin: lg_rate=0.01 -> MALA noise std sqrt(0.01)=0.1/dim -> ~0% accept.
- Random walk: step_w=0.005 -> ~1-3% accept.
- Adaptation was too weak (lg_rate x0.95/window), mis-bounded (growth cap 1e-3
  below the 0.01 start; step_w floor 0.002 too high), and used one target
  (0.40) for both proposal types.

## Fix (bnn.py + run.py)
- Smaller in-basin initial steps: step_w 0.005->0.001, lg_rate 0.01->1e-5.
- Robbins-Monro log-scale adaptation toward SEPARATE targets
  (rw_target=0.30, lg_target=0.55), every 200 steps, with sane bounds.
- Optional debug print of the RW/LG accept split (config["debug_accept"]).
- Chain now reports rw_accept / lg_accept / final step sizes.

## Result (real data)
Overall weight-accept 0.004-0.012 -> ~0.27 ; RW ~0.21, Langevin ~0.33-0.58.
Gradient finite-difference self-check still passes.

## How to run
- python bnn.py                  # gradient self-check
- python diagnose_accept_split.py # old vs fixed split, no heavy deps
- python run.py --quick           # fast pipeline run
- python run.py                   # full run (needs tensorflow, pymc)
Set "debug_accept": True in BNN_CONFIG to watch the split live.
