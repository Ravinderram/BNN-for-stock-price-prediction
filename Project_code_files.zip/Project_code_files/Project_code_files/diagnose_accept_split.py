"""
diagnose_accept_split.py
========================
Standalone diagnostic: runs the EXACT cold-chain MCMC loop from bnn.chain_worker
(temperature = 1.0) on the real training data, and prints the Langevin vs
random-walk accept split at every adaptation checkpoint.

Run from inside the bnn/ folder:
    python diagnose_accept_split.py

It compares the OLD defaults (tiny acceptance) against the FIXED config so you
can see the difference without launching the full multiprocessing pipeline.
"""
import os, math
import numpy as np

# Resolve paths relative to this file so it runs from anywhere.
HERE = os.path.dirname(os.path.abspath(__file__))

import bnn
import data as datamod

CSV = os.path.join(HERE, "MMM_clean.csv")
df = datamod.load_csv(CSV)
Xtr, ytr, Xte, yte, _, _ = datamod.normalise_and_split(
    df, train_end="2018-12-31", test_start="2019-01-01", test_end="2019-12-31")
print(f"Train windows: {Xtr.shape}, targets: {ytr.shape}  "
      f"N_scalar_outputs = {ytr.size}")

topology = (5, 5, 5)
n_p = bnn.n_params(topology)


def run_chain(n_samples, label, *, step_w, lg_rate, step_tau,
              adapt_interval, rw_target, lg_target,
              old_style_adapt, seed=42, verbose=True):
    """One cold chain. old_style_adapt=True reproduces the original ratchet
    adaptation; False uses the Robbins-Monro log-scale rule from the fix."""
    rng = np.random.RandomState(seed)
    X, y = Xtr, ytr
    sigma_w_sq, gamma_a, gamma_b, grad_clip, lg_prob = 25.0, 2.0, 0.05, 5.0, 0.50
    temperature = 1.0
    burn_steps = int(n_samples * 0.5)

    w = rng.randn(n_p) * math.sqrt(sigma_w_sq) * 0.1
    log_tau_sq = math.log(np.var(y) + 1e-6)
    w, log_tau_sq = bnn.warmup(w, log_tau_sq, X, y, topology, sigma_w_sq,
                               n_steps=200, grad_clip=grad_clip, perturb=False, rng=rng)
    cur_ll = bnn.log_likelihood(w, X, y, log_tau_sq, topology)
    cur_lp_w = bnn.log_prior_weights(w, sigma_w_sq)
    cur_lp_tau = bnn.log_prior_tau(log_tau_sq, gamma_a, gamma_b)
    rw_prop = rw_acc = lg_prop = lg_acc = total_acc = 0

    for step in range(n_samples):
        use_langevin = (rng.rand() < lg_prob)
        if use_langevin:
            grad_cur = bnn.gradient_log_posterior(w, X, y, log_tau_sq, topology, sigma_w_sq, grad_clip)
            mu_cur = w + 0.5 * lg_rate * grad_cur
            w_prop = mu_cur + math.sqrt(lg_rate) * rng.randn(n_p)
            grad_prop = bnn.gradient_log_posterior(w_prop, X, y, log_tau_sq, topology, sigma_w_sq, grad_clip)
            mu_prop = w_prop + 0.5 * lg_rate * grad_prop
            log_q_correction = (-np.sum((w - mu_prop) ** 2) / (2.0 * lg_rate)
                                + np.sum((w_prop - mu_cur) ** 2) / (2.0 * lg_rate))
            lg_prop += 1
        else:
            w_prop = w + step_w * rng.randn(n_p)
            log_q_correction = 0.0
            rw_prop += 1
        ll_w_prop = bnn.log_likelihood(w_prop, X, y, log_tau_sq, topology)
        lp_w_prop = bnn.log_prior_weights(w_prop, sigma_w_sq)
        log_alpha_w = (((ll_w_prop + lp_w_prop) - (cur_ll + cur_lp_w)) / temperature + log_q_correction)
        if math.log(rng.rand() + 1e-300) < log_alpha_w:
            w, cur_ll, cur_lp_w = w_prop, ll_w_prop, lp_w_prop
            total_acc += 1
            if use_langevin: lg_acc += 1
            else: rw_acc += 1

        log_tau_prop = float(np.clip(log_tau_sq + step_tau * rng.randn(), -10, 10))
        ll_tau_prop = bnn.log_likelihood(w, X, y, log_tau_prop, topology)
        lp_tau_prop = bnn.log_prior_tau(log_tau_prop, gamma_a, gamma_b)
        log_alpha_tau = (((ll_tau_prop + lp_tau_prop) - (cur_ll + cur_lp_tau)) / temperature)
        if math.log(rng.rand() + 1e-300) < log_alpha_tau:
            log_tau_sq, cur_ll, cur_lp_tau = log_tau_prop, ll_tau_prop, lp_tau_prop

        if (step < burn_steps) and ((step + 1) % adapt_interval == 0):
            rw_rate = rw_acc / max(rw_prop, 1)
            lg_rate_acc = lg_acc / max(lg_prop, 1)
            if verbose:
                print(f"  [{label}] step {step+1:6d}  "
                      f"RW: {rw_acc:4d}/{rw_prop:4d} = {rw_rate:6.3f}   "
                      f"LG: {lg_acc:4d}/{lg_prop:4d} = {lg_rate_acc:6.3f}   "
                      f"step_w={step_w:.2e} lg_rate={lg_rate:.2e}")
            if old_style_adapt:
                if rw_prop > 0:
                    step_w = min(step_w * 1.1, 0.05) if rw_rate > rw_target else max(step_w * 0.9, 0.002)
                    step_tau = min(step_tau * 1.1, 0.5) if rw_rate > rw_target else max(step_tau * 0.9, 0.01)
                if lg_prop > 0:
                    lg_rate = min(lg_rate * 1.05, 1e-3) if lg_rate_acc > lg_target else max(lg_rate * 0.95, 1e-6)
            else:
                if rw_prop > 0:
                    step_w = min(max(step_w * math.exp(0.5 * (rw_rate - rw_target)), 1e-5), 0.1)
                    step_tau = min(max(step_tau * math.exp(0.5 * (rw_rate - rw_target)), 1e-3), 0.5)
                if lg_prop > 0:
                    lg_rate = min(max(lg_rate * math.exp(1.0 * (lg_rate_acc - lg_target)), 1e-9), 1e-2)
            rw_prop = rw_acc = lg_prop = lg_acc = 0
    return total_acc / n_samples


if __name__ == "__main__":
    print("\n=== ORIGINAL CONFIG (broken) ===")
    r0 = run_chain(10000, "orig", step_w=0.005, lg_rate=0.01, step_tau=0.10,
                   adapt_interval=500, rw_target=0.40, lg_target=0.40,
                   old_style_adapt=True)
    print(f"OVERALL weight-accept (orig): {r0:.4f}")

    print("\n=== FIXED CONFIG ===")
    r1 = run_chain(10000, "fixed", step_w=0.001, lg_rate=1e-5, step_tau=0.05,
                   adapt_interval=200, rw_target=0.30, lg_target=0.55,
                   old_style_adapt=False)
    print(f"OVERALL weight-accept (fixed): {r1:.4f}")
