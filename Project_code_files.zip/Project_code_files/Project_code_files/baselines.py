"""
baselines.py
============
The four comparison models, all built with TensorFlow / Keras:

  FNN-Adam    feedforward network trained with Adam        (point predictions)
  FNN-SGD     feedforward network trained with SGD         (point predictions)
  LSTM        recurrent network for sequences              (point predictions)
  MC-Dropout  feedforward network with dropout kept on     (prediction intervals)

Every training function returns a results dictionary with the same keys so the
calibration and plotting code can treat all models uniformly:

    name            : str
    pred            : (n_test, 5)  mean prediction
    rmse_per_step   : list of 5 floats
    rmse_overall    : float

Models that produce intervals (MC-Dropout) additionally return:
    samples         : (n_passes, n_test, 5)
    fx_low_95       : (n_test, 5)
    fx_high_95      : (n_test, 5)
"""

import os
import numpy as np

# Keep TensorFlow quiet and deterministic-ish.
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# Silence the harmless "tf.function retracing" notice emitted during the
# MC-Dropout stochastic forward passes.
tf.get_logger().setLevel("ERROR")

tf.random.set_seed(42)

STEPS_AHEAD = 5


# ----------------------------------------------------------------------------
# Shared helpers
# ----------------------------------------------------------------------------
def _rmse_metrics(y_true, pred):
    """Per-step and overall RMSE."""
    rmse_per_step = [
        float(np.sqrt(np.mean((y_true[:, h] - pred[:, h]) ** 2)))
        for h in range(y_true.shape[1])
    ]
    rmse_overall = float(np.sqrt(np.mean((y_true - pred) ** 2)))
    return rmse_per_step, rmse_overall


def _standard_callbacks():
    """Early stopping + LR reduction shared by all Keras models."""
    return [
        keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=30, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=15, min_lr=1e-6),
    ]


# ----------------------------------------------------------------------------
# FNN-Adam
# ----------------------------------------------------------------------------
def train_fnn_adam(X_train, y_train, X_test, y_test):
    """Feedforward 5 -> 64 -> 32 -> 5, ReLU hidden, linear output, Adam."""
    keras.utils.set_random_seed(42)
    model = keras.Sequential([
        layers.Input(shape=(X_train.shape[1],)),
        layers.Dense(64, activation="relu"),
        layers.Dense(32, activation="relu"),
        layers.Dense(STEPS_AHEAD, activation="linear"),
    ])
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-3),
                  loss="mse")
    model.fit(X_train, y_train, validation_split=0.1, epochs=500,
              batch_size=32, verbose=0, callbacks=_standard_callbacks())

    pred = model.predict(X_test, verbose=0)
    rmse_per_step, rmse_overall = _rmse_metrics(y_test, pred)
    return {
        "name": "FNN-Adam",
        "pred": pred,
        "rmse_per_step": rmse_per_step,
        "rmse_overall": rmse_overall,
    }


# ----------------------------------------------------------------------------
# FNN-SGD
# ----------------------------------------------------------------------------
def train_fnn_sgd(X_train, y_train, X_test, y_test):
    """Same architecture as FNN-Adam but trained with momentum SGD."""
    keras.utils.set_random_seed(42)
    model = keras.Sequential([
        layers.Input(shape=(X_train.shape[1],)),
        layers.Dense(64, activation="relu"),
        layers.Dense(32, activation="relu"),
        layers.Dense(STEPS_AHEAD, activation="linear"),
    ])
    model.compile(
        optimizer=keras.optimizers.SGD(
            learning_rate=1e-2, momentum=0.9, nesterov=True),
        loss="mse")
    model.fit(X_train, y_train, validation_split=0.1, epochs=1000,
              batch_size=32, verbose=0, callbacks=_standard_callbacks())

    pred = model.predict(X_test, verbose=0)
    rmse_per_step, rmse_overall = _rmse_metrics(y_test, pred)
    return {
        "name": "FNN-SGD",
        "pred": pred,
        "rmse_per_step": rmse_per_step,
        "rmse_overall": rmse_overall,
    }


# ----------------------------------------------------------------------------
# LSTM
# ----------------------------------------------------------------------------
def train_lstm(X_train, y_train, X_test, y_test):
    """LSTM over the 5-step input sequence (reshaped to (5, 1))."""
    keras.utils.set_random_seed(42)
    n_in = X_train.shape[1]
    X_train_3d = X_train.reshape(-1, n_in, 1)
    X_test_3d = X_test.reshape(-1, n_in, 1)

    model = keras.Sequential([
        layers.Input(shape=(n_in, 1)),
        layers.LSTM(64, return_sequences=True),
        layers.Dropout(0.1),
        layers.LSTM(32, return_sequences=False),
        layers.Dense(STEPS_AHEAD, activation="linear"),
    ])
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-3),
                  loss="mse")
    model.fit(X_train_3d, y_train, validation_split=0.1, epochs=500,
              batch_size=32, verbose=0, shuffle=False,
              callbacks=_standard_callbacks())

    pred = model.predict(X_test_3d, verbose=0)
    rmse_per_step, rmse_overall = _rmse_metrics(y_test, pred)
    return {
        "name": "LSTM",
        "pred": pred,
        "rmse_per_step": rmse_per_step,
        "rmse_overall": rmse_overall,
    }


# ----------------------------------------------------------------------------
# MC-Dropout
# ----------------------------------------------------------------------------
class MCDropout(layers.Dropout):
    """Dropout layer that stays active at inference time.

    Overriding call() to always pass training=True means dropout is applied
    during prediction, which is what turns a deterministic network into an
    approximate Bayesian one (Gal & Ghahramani, 2016).
    """

    def call(self, inputs, training=None):
        return super().call(inputs, training=True)


def train_mc_dropout(X_train, y_train, X_test, y_test, n_passes=500):
    """Feedforward network with always-on dropout; n_passes stochastic draws."""
    keras.utils.set_random_seed(42)
    model = keras.Sequential([
        layers.Input(shape=(X_train.shape[1],)),
        layers.Dense(64, activation="relu"),
        MCDropout(0.2),
        layers.Dense(32, activation="relu"),
        MCDropout(0.2),
        layers.Dense(STEPS_AHEAD, activation="linear"),
    ])
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-3),
                  loss="mse")
    model.fit(X_train, y_train, validation_split=0.1, epochs=500,
              batch_size=32, verbose=0, callbacks=_standard_callbacks())

    # Stochastic forward passes (dropout active because of MCDropout).
    # Cast once to a tf.Tensor so repeated calls do not retrace the graph.
    n_test = X_test.shape[0]
    X_test_tf = tf.convert_to_tensor(X_test, dtype=tf.float32)
    samples = np.zeros((n_passes, n_test, STEPS_AHEAD))
    for i in range(n_passes):
        # MCDropout ignores the training flag and always drops, so each
        # call gives a different stochastic output.
        samples[i] = model(X_test_tf, training=False).numpy()

    pred_mean = samples.mean(axis=0)
    fx_low_95 = np.percentile(samples, 2.5, axis=0)
    fx_high_95 = np.percentile(samples, 97.5, axis=0)

    rmse_per_step, rmse_overall = _rmse_metrics(y_test, pred_mean)
    return {
        "name": "MC-Dropout",
        "pred": pred_mean,
        "samples": samples,
        "fx_low_95": fx_low_95,
        "fx_high_95": fx_high_95,
        "rmse_per_step": rmse_per_step,
        "rmse_overall": rmse_overall,
    }


# ----------------------------------------------------------------------------
# Convenience wrapper
# ----------------------------------------------------------------------------
def train_all_baselines(X_train, y_train, X_test, y_test, n_passes=500):
    """Train all four baselines and return a dict keyed by model name."""
    return {
        "FNN-Adam": train_fnn_adam(X_train, y_train, X_test, y_test),
        "FNN-SGD": train_fnn_sgd(X_train, y_train, X_test, y_test),
        "LSTM": train_lstm(X_train, y_train, X_test, y_test),
        "MC-Dropout": train_mc_dropout(
            X_train, y_train, X_test, y_test, n_passes=n_passes),
    }


if __name__ == "__main__":
    # Self-test on one stock / setup.
    import data

    df = data.load_all_stocks(".")["MMM"]
    cfg = data.get_experiment_splits()["W1"]
    Xtr, ytr, Xte, yte, td, sc = data.normalise_and_split(
        df, cfg["train_end"], cfg["test_start"], cfg["test_end"])

    res = train_all_baselines(Xtr, ytr, Xte, yte, n_passes=100)
    for name, r in res.items():
        line = f"{name:12s} RMSE={r['rmse_overall']:.4f}"
        if "fx_low_95" in r:
            width = float(np.mean(r["fx_high_95"] - r["fx_low_95"]))
            line += f"  mean 95% width={width:.4f}"
        print(line)
