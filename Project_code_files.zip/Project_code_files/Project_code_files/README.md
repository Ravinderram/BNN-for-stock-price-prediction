# Bayesian Neural Networks for Stock Price Forecasting
## Extension to Geopolitical Crisis Periods with Multi-Level Calibration Validation

This is the code for a Probabilistic Modelling course project that extends
Chandra & He (2021, PLOS ONE 16(7): e0253217) from COVID-19 to two later
geopolitical crises (Russia-Ukraine war, Middle East conflict), and adds a
proper multi-level calibration validation that the original paper never did.

---

## What the project does

1. Replicates the original paper's Bayesian neural network trained with
   Langevin-gradient parallel-tempering MCMC, on the same four stocks
   (MMM, CBA.AX, DAI.DE, 600118.SS), using only the Close price.
2. Extends the data to 2012-2026 and tests across six setups: two COVID
   replication setups (R1, R2), two Russia-Ukraine war setups (W1, W2), and
   two Middle East conflict setups (M1, M2).
3. Compares five models: BNN, FNN-Adam, FNN-SGD, LSTM, MC-Dropout.
4. Measures whether the prediction intervals actually hold, using calibration
   curves at seven confidence levels and Expected Calibration Error (ECE).
5. Adds three OHLCV analyses: intraday volatility charts, volatility-stratified
   calibration, and volume-spike analysis.
6. Uses a PyMC Bayesian linear regression as a reference for what good
   calibration looks like.

---

## Files

| File | Responsibility |
|------|----------------|
| `data.py` | Load CSVs, normalise, build sliding windows (D=5, T=2), define setups, OHLCV helpers |
| `bnn.py` | Langevin-gradient PT-MCMC Bayesian neural network in NumPy + multiprocessing |
| `baselines.py` | FNN-Adam, FNN-SGD, LSTM, MC-Dropout (Keras) |
| `calibration.py` | Prediction intervals, coverage, ECE, volatility-split calibration |
| `pymc_reference.py` | Bayesian linear regression reference model (PyMC NUTS) |
| `plots.py` | All figures |
| `run.py` | Orchestration; the only file you run directly |

---

## Setup

```bash
pip install -r requirements.txt
```

The four CSV files must be in the same directory as the Python files. They
have columns: Date, Open, High, Low, Close, Volume, with dates in DD-MM-YYYY.

---

## Running

```bash
# Full run (paper-faithful: 100k MCMC samples x 10 chains). Slow - hours.
python run.py

# Fast smoke test (small MCMC budget, ~1 minute per stock/setup).
python run.py --quick

# Restrict to specific stocks and/or setups.
python run.py --stocks MMM --setups W1 W2
python run.py --quick --stocks MMM CBA_AX --setups R1

# Skip the PyMC reference if PyMC is not installed.
python run.py --no-pymc
```

Stock keys: `MMM`, `CBA_AX`, `DAI_DE`, `SS_600118`.
Setup keys: `R1`, `R2`, `W1`, `W2`, `M1`, `M2`.

---

## Verifying the individual modules

Each module has a self-test you can run directly:

```bash
python data.py            # prints data ranges and window counts per setup
python bnn.py             # verifies the analytical gradient vs finite differences
python baselines.py       # trains all four baselines on one setup
python calibration.py     # confirms a calibrated Gaussian gives ECE near 0
python pymc_reference.py  # fits the Bayesian linear regression on one setup
```

The gradient check in `bnn.py` should print an error around 1e-7 and PASS.
The calibration check in `calibration.py` should print observed coverage that
tracks the nominal levels with ECE below 0.05.

---

## Output

Everything is written under `outputs/`:

```
outputs/
  results/
    {stock}_{setup}_results.json     metrics + calibration per stock/setup
    summary.csv                      one row per stock/setup/model
    ece_summary.csv                  ECE per interval model
    volatility_split_ece.csv         low- vs high-volatility ECE
    intraday_range_summary.csv       monthly intraday range per stock
    volume_spikes_{stock}_{setup}.csv
  predictions/
    {stock}_{setup}_predictions.csv  actual + predicted prices per model
  figures/
    forecast_{stock}_{setup}.png
    rmse_{stock}_{setup}.png
    calibration_{stock}_{setup}.png
    calibration_volatility_split_{stock}_{setup}.png
    volume_spikes_{stock}_{setup}.png
    volatility_intraday_{stock}.png
    calibration_combined_{setup}.png
    ece_heatmap.png
    ece_volatility_split.png
    setup_comparison_rmse.png
```

---

## Important implementation notes

- **Output activation is linear, not sigmoid.** During a crisis the test prices
  exceed the training maximum, and since inputs are min-max scaled on the
  training window only, a sigmoid output (capped at 1.0) cannot extrapolate.
  The hidden layer keeps sigmoid as in the original paper; only the output is
  linear. This is the one deliberate deviation from the paper's Section 4.2 and
  it is required for the crisis extension to work.

- **The BNN uses pure NumPy + multiprocessing**, not PyTorch or PyMC. MCMC is
  not gradient descent; the network has only 60 parameters; and the analytical
  gradient is simple. This matches the original authors' implementation.

- **Only the Close price feeds the model.** Open, High, Low and Volume are used
  exclusively for post-hoc analysis (volatility splitting, volume spikes),
  never as model inputs.

- **The PyMC reference model** is a sanity check. Because it is linear with 7
  parameters, NUTS samples it well and its calibration curve should sit close
  to the diagonal. If it does, the calibration code is trustworthy.

- The BNN's `spawn` multiprocessing start method is set inside the
  `if __name__ == "__main__"` block of `run.py`.

---

## Base references

- Chandra, R. & He, Y. (2021). Bayesian neural networks for stock price
  forecasting before and during COVID-19 pandemic. PLOS ONE 16(7): e0253217.
- Chandra, R. et al. (2019). Langevin-gradient parallel tempering for Bayesian
  neural learning. Neurocomputing 359: 315-326.
