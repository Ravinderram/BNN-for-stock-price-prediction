"""
bnn.py
======
Bayesian neural network trained with Langevin-gradient parallel-tempering
MCMC, implemented from scratch in NumPy with Python multiprocessing.

This is a faithful re-implementation of the sampler described in
Chandra et al. (2019), Neurocomputing 359: 315-326, as used by
Chandra & He (2021), PLOS ONE 16(7): e0253217.

Network
-------
One hidden layer feedforward network, topology (5, 5, 5):
  5 inputs  ->  5 hidden (sigmoid)  ->  5 outputs (LINEAR)

Note on the output activation
-----------------------------
The spec (Section 3.3) requires that the model be able to predict values
above the training maximum, because during a crisis the test prices exceed
anything seen in training and the inputs are min-max scaled on the training
window only. A sigmoid output saturates at 1.0 and cannot extrapolate, so a
LINEAR output activation is used on the final layer. The hidden layer keeps
the sigmoid activation as in the original paper.

Inference engine
----------------
- Each chain is a separate process running Metropolis-Hastings MCMC at its
  own temperature.
- A coordinator process collects the chains' states every swap_interval
  steps and proposes parallel-tempering swaps between neighbouring chains.
- Proposals mix Langevin-gradient moves (probability lg_prob) with plain
  random-walk moves. The Langevin moves require the analytical gradient of
  the log posterior and an explicit Metropolis-Hastings correction because
  the proposal is asymmetric.
"""

import time
import math
import numpy as np
import multiprocessing as mp


# ============================================================================
# Network maths
# ============================================================================
def n_params(topology):
    """Total number of weights + biases for topology (n_in, n_hid, n_out)."""
    n_in, n_hid, n_out = topology
    return n_in * n_hid + n_hid + n_hid * n_out + n_out


def unpack_weights(w, topology):
    """Split the flat parameter vector into (W1, b1, W2, b2).

    W1 : (n_in, n_hid)
    b1 : (n_hid,)
    W2 : (n_hid, n_out)
    b2 : (n_out,)
    """
    n_in, n_hid, n_out = topology
    i = 0
    W1 = w[i:i + n_in * n_hid].reshape(n_in, n_hid)
    i += n_in * n_hid
    b1 = w[i:i + n_hid]
    i += n_hid
    W2 = w[i:i + n_hid * n_out].reshape(n_hid, n_out)
    i += n_hid * n_out
    b2 = w[i:i + n_out]
    return W1, b1, W2, b2


def _sigmoid(z):
    # Numerically stable sigmoid.
    return np.where(z >= 0,
                    1.0 / (1.0 + np.exp(-z)),
                    np.exp(z) / (1.0 + np.exp(z)))


def forward(w, X, topology):
    """Forward pass.

    Hidden layer: sigmoid. Output layer: linear (see module docstring).

    X : (n_samples, n_in)
    returns : (n_samples, n_out)
    """
    W1, b1, W2, b2 = unpack_weights(w, topology)
    h = _sigmoid(X @ W1 + b1)       # (n_samples, n_hid)
    out = h @ W2 + b2              # linear output
    return out


# ============================================================================
# Probability model
# ============================================================================
def log_likelihood(w, X, y, log_tau_sq, topology, vol=None, gamma_v=0.0):
    """Gaussian log likelihood, homoskedastic or heteroskedastic.

    Homoskedastic (vol is None) - original model:
        log p(y | theta) = -0.5 * N * log(2*pi*tau_sq) - SSE / (2*tau_sq)
        where N is the total number of scalar outputs (n_samples * n_out).

    Heteroskedastic (vol given) - per-window noise variance:
        tau_i^2 = exp(log_tau_sq + gamma_v * vol_i)
        where vol_i is a standardised volatility covariate for window i (the
        std of that window's inputs, standardised with TRAIN statistics).
        With gamma_v = 0 this collapses exactly to the homoskedastic model,
        so the original model is nested inside this one. This targets the
        root cause of the BNN's crisis under-coverage: a single global
        tau_sq fitted mostly on calm data is too narrow once test-period
        volatility rises (the same mechanism temperature scaling was
        patching post-hoc, and the same fix applied to Bayes-LR).
    """
    pred = forward(w, X, topology)
    if vol is None:
        tau_sq = math.exp(log_tau_sq)
        sse = np.sum((y - pred) ** 2)
        N = y.size
        return (-0.5 * N * math.log(2.0 * math.pi * tau_sq)
                - sse / (2.0 * tau_sq))

    log_tau_i = np.clip(log_tau_sq + gamma_v * vol, -20.0, 20.0)  # (N,)
    tau_i_sq = np.exp(log_tau_i)                                   # (N,)
    resid_sq_row = np.sum((y - pred) ** 2, axis=1)                 # (N,)
    n_out = y.shape[1]
    return float(
        -0.5 * n_out * np.sum(math.log(2.0 * math.pi) + log_tau_i)
        - 0.5 * np.sum(resid_sq_row / tau_i_sq))


def log_prior_weights(w, sigma_w_sq):
    """Gaussian prior on weights: N(0, sigma_w_sq * I)."""
    n = w.size
    return (-0.5 * n * math.log(2.0 * math.pi * sigma_w_sq)
            - np.sum(w ** 2) / (2.0 * sigma_w_sq))


def log_prior_tau(log_tau_sq, gamma_a, gamma_b):
    """Gamma-like prior on the noise variance, written in log_tau_sq space.

    log p(tau_sq) = -(gamma_a + 1) * log_tau_sq - gamma_b / exp(log_tau_sq)
    """
    return -(gamma_a + 1.0) * log_tau_sq - gamma_b / math.exp(log_tau_sq)


def log_prior_gamma_v(gamma_v):
    """Standard-normal prior on the volatility coefficient gamma_v.

    N(0, 1) is weakly informative here because the volatility covariate is
    standardised; gamma_v = 0 recovers the homoskedastic model, so the prior
    gently shrinks toward the original model unless the data demand
    otherwise.
    """
    return -0.5 * gamma_v * gamma_v


# ============================================================================
# Analytical gradient of the log posterior w.r.t. the weight vector
# ============================================================================
def gradient_log_posterior(w, X, y, log_tau_sq, topology, sigma_w_sq,
                           grad_clip=5.0, vol=None, gamma_v=0.0):
    """Analytical gradient of log p(theta | data) w.r.t. theta.

    Backprop through the 2-layer network with sigmoid hidden and linear
    output. The likelihood term backpropagates the residual (y - pred)
    weighted by the (per-row, if heteroskedastic) noise variance; the prior
    term contributes -theta / sigma_w_sq. The gradient norm is clipped to
    grad_clip.
    """
    n_in, n_hid, n_out = topology
    W1, b1, W2, b2 = unpack_weights(w, topology)

    # Forward pass, keeping activations.
    z1 = X @ W1 + b1               # (N, n_hid)
    h = _sigmoid(z1)               # (N, n_hid)
    pred = h @ W2 + b2            # (N, n_out) linear

    # dL/dpred for Gaussian likelihood: (y - pred) / tau_sq
    # (gradient of log-likelihood, so positive sign on residual).
    # Heteroskedastic: each row i is weighted by its own tau_i^2.
    if vol is None:
        tau_sq = math.exp(log_tau_sq)
        dpred = (y - pred) / tau_sq    # (N, n_out)
    else:
        log_tau_i = np.clip(log_tau_sq + gamma_v * vol, -20.0, 20.0)
        tau_i_sq = np.exp(log_tau_i)                 # (N,)
        dpred = (y - pred) / tau_i_sq[:, None]        # (N, n_out)

    # Output layer (linear): grad wrt W2 and b2
    gW2 = h.T @ dpred              # (n_hid, n_out)
    gb2 = np.sum(dpred, axis=0)    # (n_out,)

    # Backprop into hidden layer
    dh = dpred @ W2.T             # (N, n_hid)
    dz1 = dh * h * (1.0 - h)       # sigmoid derivative
    gW1 = X.T @ dz1               # (n_in, n_hid)
    gb1 = np.sum(dz1, axis=0)      # (n_hid,)

    grad_ll = np.concatenate([gW1.flatten(), gb1, gW2.flatten(), gb2])

    # Prior gradient: d/dtheta [ -theta^2 / (2 sigma_w_sq) ] = -theta/sigma_w_sq
    grad_prior = -w / sigma_w_sq

    grad = grad_ll + grad_prior

    # Clip gradient norm.
    norm = np.linalg.norm(grad)
    if norm > grad_clip:
        grad = grad * (grad_clip / norm)
    return grad


# ============================================================================
# Warm-up: gradient ascent into a high-probability region
# ============================================================================
def warmup(w, log_tau_sq, X, y, topology, sigma_w_sq,
           n_steps=400, grad_clip=5.0, perturb=False, rng=None,
           vol=None, gamma_v=0.0):
    """Adaptive-learning-rate gradient ascent on the log posterior.

    Starts with lr = 1e-4, grows it by 1.1 on improvement (cap 1e-2),
    halves it on no improvement, stops if lr < 1e-8. Optionally injects a
    small perturbation every 50 steps (used by non-cold chains so they
    start from different points).
    """
    if rng is None:
        rng = np.random.RandomState(0)

    lr = 1e-4
    cur_ll = log_likelihood(w, X, y, log_tau_sq, topology, vol, gamma_v)

    for step in range(n_steps):
        grad = gradient_log_posterior(
            w, X, y, log_tau_sq, topology, sigma_w_sq, grad_clip,
            vol, gamma_v)
        w_new = w + lr * grad
        new_ll = log_likelihood(w_new, X, y, log_tau_sq, topology,
                                vol, gamma_v)

        if new_ll > cur_ll:
            w = w_new
            cur_ll = new_ll
            lr = min(lr * 1.1, 1e-2)
        else:
            lr *= 0.5
            if lr < 1e-8:
                break

        if perturb and (step + 1) % 50 == 0:
            w = w + perturb_scale(w) * rng.randn(w.size)

    return w, log_tau_sq


def perturb_scale(w):
    """Small fixed perturbation magnitude used during warm-up for hot chains."""
    return 1e-3


# ============================================================================
# Single MCMC chain (runs in its own process)
# ============================================================================
def chain_worker(chain_id, topology, X, y, vol, temperature, config,
                 report_queue, response_queue, result_queue):
    """Run one tempered MCMC chain.

    vol : per-row standardised volatility covariate (or None for the
    original homoskedastic model). When given, the noise model is
    tau_i^2 = exp(log_tau_sq + gamma_v * vol_i) and gamma_v is sampled in
    its own Metropolis block.

    Communication protocol with the coordinator:
      - Every swap_interval steps the chain sends its (chain_id, log_lik,
        w, log_tau_sq, gamma_v) to report_queue, then blocks on
        response_queue to receive the (possibly swapped) state to continue
        from.
      - At the end the chain sends its collected samples (cold chain only;
        the FULL trace including pre-burn-in steps, together with a
        `burn_index` marking where burn_steps falls) plus diagnostics to
        result_queue. The coordinator slices off the pre-burn-in part for
        posterior/calibration use and keeps the full trace for the burn-in
        stabilisation diagnostic.
    """
    seed = 42 + chain_id * 997
    rng = np.random.RandomState(seed)

    n_p = n_params(topology)
    sigma_w_sq = config["sigma_w_sq"]
    gamma_a = config["gamma_a"]
    gamma_b = config["gamma_b"]
    grad_clip = config["lg_grad_clip"]
    lg_prob = config["lg_prob"]

    n_samples = config["n_samples"]
    swap_interval = config["swap_interval"]
    burn_in = config["burn_in"]
    adapt_interval = config["adapt_interval"]

    # Separate acceptance targets for the two proposal types (random-walk
    # Metropolis ~0.234 optimal, MALA ~0.574 optimal in high dimension). Fall
    # back to the legacy single target if the new keys are absent.
    target_accept = config.get("target_accept", 0.40)
    rw_target = config.get("rw_target", target_accept)
    lg_target = config.get("lg_target", target_accept)

    # Adaptation bounds (clip the Robbins-Monro log-scale updates).
    step_w_min = config.get("step_w_min", 1e-5)
    step_w_max = config.get("step_w_max", 0.1)
    step_tau_min = config.get("step_tau_min", 1e-3)
    step_tau_max = config.get("step_tau_max", 0.5)
    lg_rate_min = config.get("lg_rate_min", 1e-9)
    lg_rate_max = config.get("lg_rate_max", 1e-2)
    debug_accept = config.get("debug_accept", False)

    # Adaptive step sizes (mutable through the run).
    step_w = config["step_w"]
    step_tau = config["step_tau"]
    lg_rate = config["lg_rate"]

    is_cold = (chain_id == 0)
    hetero = vol is not None

    # ----- initialise -----
    w = rng.randn(n_p) * math.sqrt(sigma_w_sq) * 0.1
    log_tau_sq = math.log(np.var(y) + 1e-6)
    gamma_v = 0.0                       # homoskedastic starting point
    step_gv = config.get("step_gv", 0.05)
    gv_target = config.get("gv_target", 0.44)  # optimal for scalar RW

    # Warm-up (cold chain has no perturbation; hot chains do).
    w, log_tau_sq = warmup(
        w, log_tau_sq, X, y, topology, sigma_w_sq,
        n_steps=config["warmup_steps"], grad_clip=grad_clip,
        perturb=(not is_cold), rng=rng, vol=vol, gamma_v=gamma_v)

    cur_ll = log_likelihood(w, X, y, log_tau_sq, topology, vol, gamma_v)
    cur_lp = (log_prior_weights(w, sigma_w_sq)
              + log_prior_tau(log_tau_sq, gamma_a, gamma_b)
              + (log_prior_gamma_v(gamma_v) if hetero else 0.0))

    burn_steps = int(n_samples * burn_in)

    # Storage of weight samples (cold chain only, to save memory).
    # The cold chain saves its FULL trajectory (pre- and post-burn-in) so the
    # burn-in stabilisation diagnostic can inspect where the chain actually
    # settles; `burn_steps` is returned as `burn_index` so callers can slice
    # out the post-burn-in part for the posterior. Memory impact is small:
    # only one chain is affected (~n_samples x n_params x 8 bytes).
    saved_w = []
    saved_tau = []
    saved_gv = []

    # Acceptance bookkeeping, tracked separately for RW and Langevin moves.
    # The windowed counters reset each adaptation interval; the *_tot counters
    # accumulate over the whole run so we can report the final split.
    rw_prop = rw_acc = 0
    lg_prop = lg_acc = 0
    gv_prop = gv_acc = 0
    rw_prop_tot = rw_acc_tot = 0
    lg_prop_tot = lg_acc_tot = 0
    total_acc = 0

    # Track current log-prior split so each block updates independently.
    cur_lp_w = log_prior_weights(w, sigma_w_sq)
    cur_lp_tau = log_prior_tau(log_tau_sq, gamma_a, gamma_b)
    cur_lp_gv = log_prior_gamma_v(gamma_v) if hetero else 0.0

    for step in range(n_samples):

        # ================================================================
        # BLOCK 1: update the WEIGHTS, holding tau fixed.
        # Weights and tau are updated as two separate Metropolis steps
        # (Gibbs-style blocking). This is critical: updating them jointly
        # means a good weight move gets rejected whenever the simultaneous
        # tau kick is bad, which collapses the acceptance rate. Splitting
        # the blocks lets each accept/reject on its own merits.
        # ================================================================
        use_langevin = (rng.rand() < lg_prob)

        if use_langevin:
            # ----- Langevin-gradient proposal (asymmetric) -----
            grad_cur = gradient_log_posterior(
                w, X, y, log_tau_sq, topology, sigma_w_sq, grad_clip,
                vol, gamma_v)
            mu_cur = w + 0.5 * lg_rate * grad_cur
            w_prop = mu_cur + math.sqrt(lg_rate) * rng.randn(n_p)

            grad_prop = gradient_log_posterior(
                w_prop, X, y, log_tau_sq, topology, sigma_w_sq, grad_clip,
                vol, gamma_v)
            mu_prop = w_prop + 0.5 * lg_rate * grad_prop

            # log q(theta | theta') - log q(theta' | theta)
            log_q_correction = (
                -np.sum((w - mu_prop) ** 2) / (2.0 * lg_rate)
                + np.sum((w_prop - mu_cur) ** 2) / (2.0 * lg_rate)
            )
            lg_prop += 1
            lg_prop_tot += 1
        else:
            # ----- random-walk proposal (symmetric) -----
            w_prop = w + step_w * rng.randn(n_p)
            log_q_correction = 0.0
            rw_prop += 1
            rw_prop_tot += 1

        # Likelihood/prior of the weight proposal, tau held fixed.
        ll_w_prop = log_likelihood(w_prop, X, y, log_tau_sq, topology,
                                   vol, gamma_v)
        lp_w_prop = log_prior_weights(w_prop, sigma_w_sq)

        log_alpha_w = (
            ((ll_w_prop + lp_w_prop) - (cur_ll + cur_lp_w)) / temperature
            + log_q_correction
        )

        if math.log(rng.rand() + 1e-300) < log_alpha_w:
            w = w_prop
            cur_ll = ll_w_prop
            cur_lp_w = lp_w_prop
            total_acc += 1
            if use_langevin:
                lg_acc += 1
                lg_acc_tot += 1
            else:
                rw_acc += 1
                rw_acc_tot += 1

        # ================================================================
        # BLOCK 2: update TAU, holding the (possibly updated) weights fixed.
        # Random walk in log space, with its own accept/reject.
        # ================================================================
        log_tau_prop = log_tau_sq + step_tau * rng.randn()
        log_tau_prop = float(np.clip(log_tau_prop, -10.0, 10.0))

        ll_tau_prop = log_likelihood(w, X, y, log_tau_prop, topology,
                                     vol, gamma_v)
        lp_tau_prop = log_prior_tau(log_tau_prop, gamma_a, gamma_b)

        log_alpha_tau = (
            ((ll_tau_prop + lp_tau_prop) - (cur_ll + cur_lp_tau))
            / temperature
        )

        if math.log(rng.rand() + 1e-300) < log_alpha_tau:
            log_tau_sq = log_tau_prop
            cur_ll = ll_tau_prop
            cur_lp_tau = lp_tau_prop

        # ================================================================
        # BLOCK 3 (heteroskedastic only): update GAMMA_V, the volatility
        # coefficient, holding weights and tau fixed. Random walk with its
        # own accept/reject, exactly like the tau block. gamma_v = 0
        # recovers the homoskedastic model, so this block simply stays near
        # 0 when the data carry no volatility signal.
        # ================================================================
        if hetero:
            gv_prop_val = gamma_v + step_gv * rng.randn()
            gv_prop_val = float(np.clip(gv_prop_val, -5.0, 5.0))

            ll_gv_prop = log_likelihood(w, X, y, log_tau_sq, topology,
                                        vol, gv_prop_val)
            lp_gv_prop = log_prior_gamma_v(gv_prop_val)

            log_alpha_gv = (
                ((ll_gv_prop + lp_gv_prop) - (cur_ll + cur_lp_gv))
                / temperature
            )
            gv_prop += 1
            if math.log(rng.rand() + 1e-300) < log_alpha_gv:
                gamma_v = gv_prop_val
                cur_ll = ll_gv_prop
                cur_lp_gv = lp_gv_prop
                gv_acc += 1

        # Combined current log prior (used by swap reporting below).
        cur_lp = cur_lp_w + cur_lp_tau + cur_lp_gv

        # ----- adapt step sizes during burn-in -----
        if (step < burn_steps) and ((step + 1) % adapt_interval == 0):
            rw_rate = rw_acc / max(rw_prop, 1)
            lg_rate_acc = lg_acc / max(lg_prop, 1)

            # Diagnostic: print the Langevin vs random-walk accept split at
            # every adaptation checkpoint (cold chain only, when enabled).
            if debug_accept and is_cold:
                print(
                    f"  [BNN accept-split] step {step + 1:7d}  "
                    f"RW: {rw_acc:4d}/{rw_prop:4d} = {rw_rate:6.3f}   "
                    f"LG: {lg_acc:4d}/{lg_prop:4d} = {lg_rate_acc:6.3f}   "
                    f"step_w={step_w:.2e}  step_tau={step_tau:.2e}  "
                    f"lg_rate={lg_rate:.2e}",
                    flush=True,
                )

            # Robbins-Monro log-scale adaptation toward separate targets.
            # Updating log(step) by a multiple of (rate - target) is the
            # standard self-tuning rule: it moves the step in the right
            # direction by an amount proportional to how far off target we
            # are, and is numerically stable because it is multiplicative.
            if rw_prop > 0:
                step_w *= math.exp(0.5 * (rw_rate - rw_target))
                step_w = min(max(step_w, step_w_min), step_w_max)
                step_tau *= math.exp(0.5 * (rw_rate - rw_target))
                step_tau = min(max(step_tau, step_tau_min), step_tau_max)
            if lg_prop > 0:
                # Langevin acceptance is more sensitive to its rate, so it gets
                # a slightly larger gain.
                lg_rate *= math.exp(1.0 * (lg_rate_acc - lg_target))
                lg_rate = min(max(lg_rate, lg_rate_min), lg_rate_max)
            if hetero and gv_prop > 0:
                # Same Robbins-Monro rule for the scalar gamma_v walk
                # (optimal scalar RW acceptance ~0.44).
                gv_rate_acc = gv_acc / gv_prop
                step_gv *= math.exp(0.5 * (gv_rate_acc - gv_target))
                step_gv = min(max(step_gv, 1e-4), 1.0)

            # reset window counters
            rw_prop = rw_acc = 0
            lg_prop = lg_acc = 0
            gv_prop = gv_acc = 0

        # ----- save sample (cold chain: FULL trace, incl. pre-burn-in) -----
        # Previously this discarded everything before burn_steps, so the
        # pre-burn-in trajectory was never available for diagnostics. The
        # cold chain now saves every step; `burn_index` in the result marks
        # where burn_steps falls so post-burn-in samples can still be sliced
        # out for the posterior/calibration logic. Hot chains are untouched.
        if is_cold:
            saved_w.append(w.copy())
            saved_tau.append(log_tau_sq)
            saved_gv.append(gamma_v)

        # ----- parallel-tempering swap point -----
        if (step + 1) % swap_interval == 0:
            report_queue.put((chain_id, cur_ll, w.copy(), log_tau_sq,
                              gamma_v))
            new_state = response_queue.get()
            if new_state is not None:
                w_new, log_tau_new, gv_new, temp_new = new_state
                # The coordinator may retune this chain's ladder temperature
                # during burn-in (adaptive ladder); it is frozen afterwards.
                # The cold chain always receives T = 1.0.
                temperature = temp_new
                w = w_new
                log_tau_sq = log_tau_new
                gamma_v = gv_new
                cur_ll = log_likelihood(w, X, y, log_tau_sq, topology,
                                        vol, gamma_v)
                cur_lp_w = log_prior_weights(w, sigma_w_sq)
                cur_lp_tau = log_prior_tau(log_tau_sq, gamma_a, gamma_b)
                cur_lp_gv = log_prior_gamma_v(gamma_v) if hetero else 0.0
                cur_lp = cur_lp_w + cur_lp_tau + cur_lp_gv

    overall_accept = total_acc / n_samples
    rw_accept = rw_acc_tot / max(rw_prop_tot, 1)
    lg_accept = lg_acc_tot / max(lg_prop_tot, 1)

    result = {
        "chain_id": chain_id,
        "temperature": temperature,
        "accept_rate": overall_accept,
        "rw_accept": rw_accept,
        "lg_accept": lg_accept,
        "final_step_w": step_w,
        "final_step_tau": step_tau,
        "final_lg_rate": lg_rate,
        "final_step_gv": step_gv if hetero else None,
    }
    if is_cold:
        result["samples_w"] = np.array(saved_w)
        result["samples_tau"] = np.array(saved_tau)
        result["samples_gv"] = np.array(saved_gv)
        result["burn_index"] = burn_steps  # where burn-in ends in the trace
    result_queue.put(result)


# ============================================================================
# Effective sample size (simple initial-positive-sequence estimator)
# ============================================================================
def _ess_1d(x):
    """Effective sample size of a 1-D chain via autocorrelation.

    ESS = n / (1 + 2 * sum_k rho_k), summing autocorrelations rho_k until
    the first non-positive value (Geyer's initial positive sequence,
    simplified). Pure numpy, so bnn.py keeps no extra dependencies; arviz
    gives near-identical numbers for well-behaved chains.
    """
    x = np.asarray(x, dtype=float).ravel()
    n = len(x)
    if n < 10:
        return float(n)
    x = x - x.mean()
    var = np.dot(x, x) / n
    if var <= 0:
        return float(n)
    max_lag = min(n // 2, 2000)
    rho_sum = 0.0
    for k in range(1, max_lag):
        rho = np.dot(x[:-k], x[k:]) / ((n - k) * var)
        if rho <= 0:
            break
        rho_sum += rho
    return float(min(n, n / (1.0 + 2.0 * rho_sum)))


# ============================================================================
# Coordinator: launches chains and manages swaps
# ============================================================================
def run_bnn(X_train, y_train, X_test, y_test, topology, config):
    """Run the full LG-PT-MCMC BNN and return a results dictionary.

    The dictionary follows the same conventions as the baselines so that the
    calibration and plotting code can treat all models uniformly:
        pred           : (n_test, n_out) posterior mean
        samples        : (n_kept, n_test, n_out) posterior predictive draws
        fx_low_95      : (n_test, n_out) 2.5th percentile
        fx_high_95     : (n_test, n_out) 97.5th percentile
        rmse_per_step  : list of n_out floats
        rmse_overall   : float
        accept_rate    : cold-chain acceptance rate
        burnin_diag    : dict with the full-trace burn-in diagnostic
                         (trace, indices, burn_index, n_total)
        name           : "BNN"
    """
    n_chains = config["n_chains"]
    max_temp = config["max_temp"]
    swap_interval = config["swap_interval"]
    n_samples = config["n_samples"]
    hetero = bool(config.get("heteroskedastic", False))

    # Volatility covariate for the heteroskedastic noise model: std of each
    # window's inputs, standardised with TRAIN statistics only (no test-set
    # leakage; the covariate is observable from the inputs alone, so it is
    # available at test time and lets tau_i widen during crisis windows).
    if hetero:
        vol_train_raw = X_train.std(axis=1)
        vol_mu = float(vol_train_raw.mean())
        vol_sd = float(vol_train_raw.std()) or 1.0
        vol_train = (vol_train_raw - vol_mu) / vol_sd
        vol_test = (X_test.std(axis=1) - vol_mu) / vol_sd
    else:
        vol_train = None
        vol_test = None

    # Geometric temperature ladder from 1.0 (cold) to max_temp (hot).
    temperatures = np.geomspace(1.0, max_temp, n_chains)

    # Queues: one report queue shared by all chains, one response queue per
    # chain, one result queue shared by all chains.
    report_queue = mp.Queue()
    response_queues = [mp.Queue() for _ in range(n_chains)]
    result_queue = mp.Queue()

    procs = []
    for cid in range(n_chains):
        p = mp.Process(
            target=chain_worker,
            args=(cid, topology, X_train, y_train, vol_train,
                  float(temperatures[cid]),
                  config, report_queue, response_queues[cid], result_queue),
        )
        p.start()
        procs.append(p)

    n_swap_rounds = n_samples // swap_interval
    swap_attempts = 0
    swap_accepts = 0
    rng = np.random.RandomState(12345)

    # ------------------------------------------------------------------
    # Adaptive temperature ladder (Vousden, Farr & Mandel 2016 style).
    # The swap acceptance between neighbours depends on the product of the
    # temperature gap (1/Ta - 1/Tb) and the chain-to-chain log-likelihood
    # difference (llb - lla), whose magnitude scales with the training-set
    # size N (the log-likelihood is a sum over N points). No single fixed
    # geometric ladder is right for all 24 stock/setup combinations, so
    # during burn-in each neighbour gap is tuned by stochastic
    # approximation toward a per-pair target acceptance (~0.234): the log
    # of each gap gets a decaying-gain Robbins-Monro update
    #     S_k += kappa(t) * (accepted - target)
    # with kappa(t) = kappa0 * t0 / (t + t0). The cold chain stays fixed at
    # T = 1.0 (its samples are the posterior), and the ladder FREEZES once
    # burn-in ends, so all post-burn-in samples come from a fixed,
    # detailed-balance-respecting scheme. Chains are told their (possibly
    # updated) temperature together with the swapped state each round.
    # ------------------------------------------------------------------
    adaptive = bool(config.get("adaptive_ladder", False))
    swap_target = float(config.get("swap_target", 0.234))
    kappa0 = float(config.get("ladder_kappa0", 0.6))
    ladder_t0 = float(config.get("ladder_t0", 100.0))
    # Delay before adaptation starts (in swap rounds): right after warm-up
    # all chains sit near the same state, so nearly every swap is accepted
    # regardless of the gap; adapting on those spurious accepts inflates
    # the gaps before the chains have equilibrated to their temperatures.
    adapt_delay = int(config.get("ladder_adapt_delay", 25))
    gap_min = 1e-3
    gap_max = float(config.get("ladder_max_gap", 20.0))
    burn_rounds = int(n_samples * config["burn_in"]) // max(swap_interval, 1)

    # Log-gaps of the current ladder; temperatures rebuilt from these.
    log_gaps = np.log(np.maximum(np.diff(temperatures), gap_min))

    # Per-pair bookkeeping. Post-burn-in counters are the health metric:
    # they measure the FROZEN ladder's swap rate, which is what matters for
    # the quality of the posterior samples.
    n_pairs = n_chains - 1
    pair_att_post = np.zeros(n_pairs)
    pair_acc_post = np.zeros(n_pairs)
    pair_round = np.zeros(n_pairs)      # per-pair attempt count (for kappa)

    # Progress bar over swap rounds. tqdm is optional; if it is not installed
    # we fall back to a simple percentage print every 5% of the way through.
    try:
        from tqdm import tqdm
        progress = tqdm(total=n_swap_rounds, desc="  BNN sampling",
                        unit="round", ncols=80, leave=False)
        _use_tqdm = True
    except Exception:
        progress = None
        _use_tqdm = False
    _report_every = max(1, n_swap_rounds // 20)

    t0 = time.time()
    for rnd in range(n_swap_rounds):
        # Collect one report from each chain.
        states = {}
        for _ in range(n_chains):
            cid, ll, w, log_tau, gv = report_queue.get()
            states[cid] = [ll, w, log_tau, gv]

        # Alternating even/odd neighbour swaps.
        if rnd % 2 == 0:
            pairs = [(k, k + 1) for k in range(0, n_chains - 1, 2)]
        else:
            pairs = [(k, k + 1) for k in range(1, n_chains - 1, 2)]

        in_burn = rnd < burn_rounds
        adapting = adaptive and in_burn and rnd >= adapt_delay
        for (a, b) in pairs:
            Ta = temperatures[a]
            Tb = temperatures[b]
            lla = states[a][0]
            llb = states[b][0]
            log_swap = (1.0 / Ta - 1.0 / Tb) * (llb - lla)
            swap_attempts += 1
            accepted = math.log(rng.rand() + 1e-300) < log_swap
            if accepted:
                # Swap the full (weights, tau, gamma_v) state between the
                # two chains.
                states[a][1], states[b][1] = states[b][1], states[a][1]
                states[a][2], states[b][2] = states[b][2], states[a][2]
                states[a][3], states[b][3] = states[b][3], states[a][3]
                swap_accepts += 1

            k = a  # pair index (pairs are always (k, k+1))
            if adapting:
                pair_round[k] += 1
                kappa = kappa0 * ladder_t0 / (pair_round[k] + ladder_t0)
                log_gaps[k] += kappa * ((1.0 if accepted else 0.0)
                                        - swap_target)
                log_gaps[k] = float(np.clip(log_gaps[k],
                                            math.log(gap_min),
                                            math.log(gap_max)))
            if not in_burn:
                pair_att_post[k] += 1
                pair_acc_post[k] += 1.0 if accepted else 0.0

        # Rebuild the ladder from the (possibly updated) gaps. The cold
        # chain is always T = 1.0. After burn-in the gaps no longer change,
        # so this is a no-op there.
        if adapting:
            temperatures = np.concatenate(
                ([1.0], 1.0 + np.cumsum(np.exp(log_gaps))))

        # Send each chain its (possibly swapped) state back, together with
        # its current ladder temperature.
        for cid in range(n_chains):
            response_queues[cid].put(
                (states[cid][1], states[cid][2], states[cid][3],
                 float(temperatures[cid])))

        # Advance the progress indicator.
        if _use_tqdm:
            progress.update(1)
        elif (rnd + 1) % _report_every == 0:
            pct = 100.0 * (rnd + 1) / n_swap_rounds
            print(f"  BNN sampling: {pct:5.1f}%  "
                  f"({rnd + 1}/{n_swap_rounds} rounds)", flush=True)

    if _use_tqdm:
        progress.close()

    # Collect results from all chains.
    results_raw = {}
    for _ in range(n_chains):
        r = result_queue.get()
        results_raw[r["chain_id"]] = r

    for p in procs:
        p.join()

    elapsed = time.time() - t0
    swap_rate = swap_accepts / max(swap_attempts, 1)
    # Health metric for Task 6: the swap rate of the FROZEN ladder, i.e.
    # measured only on post-burn-in rounds (the samples that actually form
    # the posterior). Healthy range ~20-40%; below ~10% is poor mixing.
    swap_rate_post = (float(pair_acc_post.sum())
                      / max(float(pair_att_post.sum()), 1.0))
    swap_rate_per_pair = [
        float(pair_acc_post[k] / pair_att_post[k])
        if pair_att_post[k] > 0 else float("nan")
        for k in range(n_pairs)
    ]
    print(f"    PT swap rate (post-burn-in, frozen ladder) = "
          f"{swap_rate_post:.3f}"
          + (f"  [adaptive ladder, T_max = {temperatures[-1]:.3f}]"
             if adaptive else "  [fixed ladder]"))

    # ----- posterior prediction from the cold chain -----
    cold = results_raw[0]
    samples_w_full = cold["samples_w"]       # FULL cold-chain trace
    samples_tau_full = cold["samples_tau"]
    burn_index = int(cold.get("burn_index", 0))

    # --- burn-in stabilisation diagnostic trace -------------------------
    # Predicted value at the first test point (first forecast step), traced
    # over the FULL chain (pre- and post-burn-in) so we can check where the
    # chain actually stabilises vs the configured burn-in cut. Thinned to at
    # most `diag_max_points` to keep the forward passes and plotting cheap.
    diag_max_points = int(config.get("diag_max_points", 20000))
    n_full = len(samples_w_full)
    if n_full > diag_max_points:
        diag_idx = np.linspace(0, n_full - 1, diag_max_points).astype(int)
    else:
        diag_idx = np.arange(n_full)
    x_first = X_test[:1]
    diag_trace = np.array([
        float(forward(samples_w_full[i], x_first, topology)[0, 0])
        for i in diag_idx
    ])

    # --- posterior slice: post-burn-in only, exactly as before ----------
    samples_w = samples_w_full[burn_index:]
    samples_tau_post = samples_tau_full[burn_index:]
    samples_gv_full = cold.get("samples_gv")
    samples_gv_post = (samples_gv_full[burn_index:]
                       if samples_gv_full is not None
                       and len(samples_gv_full) else None)
    max_keep = config["max_posterior_samples"]

    if len(samples_w) > max_keep:
        idx = np.linspace(0, len(samples_w) - 1, max_keep).astype(int)
        samples_w = samples_w[idx]
        samples_tau = samples_tau_post[idx]
        samples_gv = (samples_gv_post[idx]
                      if samples_gv_post is not None else None)
    else:
        samples_tau = samples_tau_post
        samples_gv = samples_gv_post

    # --- effective sample size (ESS) of the cold-chain posterior --------
    # Only the cold chain's post-burn-in samples form the posterior; if they
    # are highly autocorrelated their effective diversity is much smaller
    # than their count, which artificially narrows the posterior (an
    # independent, second source of under-coverage besides the noise model).
    post_start = np.searchsorted(diag_idx, burn_index)
    ess_pred = _ess_1d(diag_trace[post_start:])
    ess_tau = _ess_1d(np.asarray(samples_tau_post, dtype=float))
    n_post = len(samples_tau_post)
    print(f"    BNN cold-chain ESS: pred@first-test-point = {ess_pred:.0f}, "
          f"tau = {ess_tau:.0f}  (out of {n_post} post-burn-in samples)")
    if min(ess_pred, ess_tau) < 0.02 * max(n_post, 1):
        print("    WARNING: very low ESS relative to sample count - the "
              "posterior may be narrower than it should be (high "
              "autocorrelation).")

    n_keep = len(samples_w)
    n_test = X_test.shape[0]
    n_out = topology[2]

    # Posterior predictive draws.
    #
    # A predictive interval for an OBSERVED price has two sources of
    # uncertainty: (1) uncertainty in the network weights, captured by the
    # spread of forward(w_i, X) across posterior samples, and (2) the
    # observation noise itself, with variance tau^2. The first alone is a
    # credible interval for the latent mean and is far too narrow to contain
    # real observations. To validate calibration against real data we must
    # form the full POSTERIOR PREDICTIVE distribution by adding Gaussian
    # observation noise N(0, tau_i^2) to each weight-based prediction.
    rng_pred = np.random.RandomState(2024)
    pred_mean_samples = np.zeros((n_keep, n_test, n_out))   # noise-free means
    pred_samples = np.zeros((n_keep, n_test, n_out))        # full predictive
    for i in range(n_keep):
        f = forward(samples_w[i], X_test, topology)
        pred_mean_samples[i] = f
        if hetero and samples_gv is not None:
            # Per-test-row noise scale from the heteroskedastic model:
            # tau_i^2 = exp(log_tau_sq + gamma_v * vol_i), evaluated at each
            # posterior draw of (log_tau_sq, gamma_v) and each test window's
            # volatility covariate.
            log_tau_i = np.clip(
                samples_tau[i] + samples_gv[i] * vol_test, -20.0, 20.0)
            tau_i = np.sqrt(np.exp(log_tau_i))               # (n_test,)
            pred_samples[i] = f + tau_i[:, None] * rng_pred.randn(
                n_test, n_out)
        else:
            tau = math.sqrt(math.exp(samples_tau[i]))
            pred_samples[i] = f + tau * rng_pred.randn(n_test, n_out)

    # Point prediction is the mean of the noise-free network outputs.
    pred_mean = pred_mean_samples.mean(axis=0)
    # Intervals come from the full posterior predictive (weights + noise).
    fx_low_95 = np.percentile(pred_samples, 2.5, axis=0)
    fx_high_95 = np.percentile(pred_samples, 97.5, axis=0)

    # Metrics.
    rmse_per_step = [
        float(np.sqrt(np.mean((y_test[:, h] - pred_mean[:, h]) ** 2)))
        for h in range(n_out)
    ]
    rmse_overall = float(np.sqrt(np.mean((y_test - pred_mean) ** 2)))

    return {
        "name": "BNN",
        "pred": pred_mean,
        "samples": pred_samples,
        "fx_low_95": fx_low_95,
        "fx_high_95": fx_high_95,
        "rmse_per_step": rmse_per_step,
        "rmse_overall": rmse_overall,
        "accept_rate": float(cold["accept_rate"]),
        "rw_accept": float(cold.get("rw_accept", float("nan"))),
        "lg_accept": float(cold.get("lg_accept", float("nan"))),
        "swap_rate": float(swap_rate),
        "swap_rate_post_burnin": float(swap_rate_post),
        "swap_rate_per_pair": swap_rate_per_pair,
        "adaptive_ladder": adaptive,
        "final_temperatures": [float(t) for t in temperatures],
        "elapsed_sec": float(elapsed),
        "n_posterior_samples": int(n_keep),
        # BNN improvement diagnostics (heteroskedastic noise + ESS check).
        "heteroskedastic": hetero,
        "gamma_v_mean": (float(np.mean(samples_gv))
                         if hetero and samples_gv is not None else None),
        "ess_pred": float(ess_pred),
        "ess_tau": float(ess_tau),
        # Burn-in stabilisation diagnostic (Task 2): full-trace predicted
        # value at the first test point + where the configured cut falls.
        "burnin_diag": {
            "trace": diag_trace,
            "indices": diag_idx,
            "burn_index": burn_index,
            "n_total": int(n_full),
        },
    }


# ============================================================================
# Gradient self-check (run this module directly to verify the gradient)
# ============================================================================
def _finite_difference_check():
    """Verify the analytical gradient against finite differences.

    Checks BOTH the homoskedastic and the heteroskedastic likelihood paths.
    """
    rng = np.random.RandomState(1)
    topology = (5, 5, 5)
    n_p = n_params(topology)
    X = rng.rand(20, 5)
    y = rng.rand(20, 5)
    w = rng.randn(n_p) * 0.5
    log_tau_sq = math.log(0.1)
    sigma_w_sq = 25.0
    vol = rng.randn(20)
    gamma_v = 0.35

    for name, v, gv in (("homoskedastic", None, 0.0),
                        ("heteroskedastic", vol, gamma_v)):
        # No clipping for the check (use a huge clip threshold).
        grad_analytic = gradient_log_posterior(
            w, X, y, log_tau_sq, topology, sigma_w_sq, grad_clip=1e9,
            vol=v, gamma_v=gv)

        def log_post(wv):
            return (log_likelihood(wv, X, y, log_tau_sq, topology, v, gv)
                    + log_prior_weights(wv, sigma_w_sq))

        eps = 1e-6
        max_err = 0.0
        for k in range(n_p):
            wp = w.copy(); wp[k] += eps
            wm = w.copy(); wm[k] -= eps
            fd = (log_post(wp) - log_post(wm)) / (2.0 * eps)
            err = abs(fd - grad_analytic[k])
            max_err = max(max_err, err)
        print(f"[{name}] Max abs gradient error vs finite difference: "
              f"{max_err:.3e}")
        assert max_err < 1e-4, f"Gradient check FAILED ({name})"
        print(f"[{name}] Gradient check PASSED")


if __name__ == "__main__":
    _finite_difference_check()
